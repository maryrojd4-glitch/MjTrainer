package com.mj.trainer

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.LeadingMarginSpan
import android.text.style.StyleSpan
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/**
 * Панель с советом поверх игры. Сам текст не принимает нажатия (они идут в игру).
 * Двигается только маленькая ручка в левом верхнем углу панели.
 */
class OverlayPanel(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = ctx.getSharedPreferences("mj", Context.MODE_PRIVATE)
    private var tv: TextView? = null
    private var handle: TextView? = null
    private var lpText: WindowManager.LayoutParams? = null
    private var lpHandle: WindowManager.LayoutParams? = null
    private var corner: String = "bl"
    private var screenW = 0
    private var screenH = 0
    private var handleSize = 0

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    @Suppress("DEPRECATION")
    private fun create(c: String) {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        screenW = Math.max(m.widthPixels, m.heightPixels)
        screenH = Math.min(m.widthPixels, m.heightPixels)
        handleSize = (screenH * 0.075f).toInt()
        corner = c

        val t = TextView(ctx)
        t.setBackgroundColor(Color.argb(210, 0, 0, 0))
        t.setTextColor(Color.WHITE)
        t.setPadding(10, 6, 14, 6)
        t.maxWidth = (screenW * 0.30f).toInt()
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, screenH * 0.030f)
        val lt = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lt.gravity = Gravity.TOP or Gravity.START
        lt.x = 0
        lt.y = 0

        val hd = TextView(ctx)
        hd.text = "✥"
        hd.gravity = Gravity.CENTER
        hd.setTextColor(Color.WHITE)
        hd.setBackgroundColor(Color.argb(130, 80, 80, 80))
        hd.setTextSize(TypedValue.COMPLEX_UNIT_PX, handleSize * 0.7f)
        val lh = WindowManager.LayoutParams(
            handleSize, handleSize, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lh.gravity = Gravity.TOP or Gravity.START

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        hd.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY
                    startX = lt.x; startY = lt.y
                }
                MotionEvent.ACTION_MOVE -> {
                    val tw = Math.max(t.width, handleSize)
                    val th = t.height
                    val nx = Math.max(0, Math.min(screenW - tw, startX + (ev.rawX - downX).toInt()))
                    val ny = Math.max(0, Math.min(screenH - th, startY + (ev.rawY - downY).toInt()))
                    applyPos(nx, ny)
                }
                MotionEvent.ACTION_UP -> {
                    prefs.edit().putInt("px2", lt.x).putInt("py2", lt.y).apply()
                }
            }
            true
        }
        wm.addView(t, lt)
        wm.addView(hd, lh)
        tv = t; handle = hd; lpText = lt; lpHandle = lh
    }

    private fun applyPos(x: Int, y: Int) {
        val lt = lpText ?: return
        val lh = lpHandle ?: return
        lt.x = x; lt.y = y; lh.x = x; lh.y = y
        try {
            wm.updateViewLayout(tv, lt)
            wm.updateViewLayout(handle, lh)
        } catch (e: Throwable) { }
    }

    /** Ставит панель на сохранённое место, а если его нет, в выбранный угол. Вызывается после смены текста. */
    private fun place() {
        val t = tv ?: return
        t.post {
            val w = Math.max(t.width, handleSize)
            val h = Math.max(t.height, handleSize)
            val px = prefs.getInt("px2", -1)
            val py = prefs.getInt("py2", -1)
            if (px >= 0 && py >= 0) {
                applyPos(Math.max(0, Math.min(screenW - w, px)), Math.max(0, Math.min(screenH - h, py)))
            } else {
                // внизу панель не доходит до ряда с рукой (он начинается на 85% высоты) — чтобы не закрывать тайлы
                val x = if (corner == "br" || corner == "tr") screenW - w else 0
                val y = if (corner == "bl" || corner == "br") (screenH * 0.78f).toInt() - h else 0
                applyPos(x, Math.max(0, y))
            }
        }
    }

    fun show(lines: List<String>, newCorner: String, big: Boolean = false, fold: Boolean = false) {
        if (tv != null && newCorner != corner) hide()
        if (tv == null) create(newCorner)
        val sb = SpannableStringBuilder()
        val main = if (fold) Color.rgb(255, 140, 90) else Color.rgb(255, 220, 80)
        for ((i, line) in lines.withIndex()) {
            val start = sb.length
            sb.append(line)
            if (i == 0) {
                sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(ForegroundColorSpan(main), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(AbsoluteSizeSpan((screenH * (if (big) 0.075f else 0.042f)).toInt()), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(LeadingMarginSpan.Standard(handleSize, 0), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            if (i < lines.size - 1) sb.append('\n')
        }
        tv?.text = sb
        tv?.visibility = View.VISIBLE
        place()
    }

    /** Прячет текст совета, ручка для перетаскивания остаётся. */
    fun clear() {
        if (tv == null) return
        tv?.text = ""
        tv?.visibility = View.GONE
    }

    fun hide() {
        try { tv?.let { wm.removeView(it) } } catch (e: Throwable) { }
        try { handle?.let { wm.removeView(it) } } catch (e: Throwable) { }
        tv = null; handle = null; lpText = null; lpHandle = null
    }
}
