package com.mj.trainer

/** Общее состояние между службой захвата и главным экраном. */
object Shared {
    @Volatile var status: String = "Остановлено"
    @Volatile var full: String = ""
    @Volatile var running: Boolean = false
}
