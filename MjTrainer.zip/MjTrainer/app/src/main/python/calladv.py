"""Советы по взятиям (чи/пон) на сбросы соперников: сравниваем «пас» и лучший сброс после взятия."""
import advisor as A
from advisor import tile2, build_hand2, kname, Valuation, hand_outlook, Rules, counts_by_kind, NUM_KINDS
from jansou.analysis.shanten import shanten_counts

RULES = Rules(kuitan=True, aka_dora=True, nagashi_mangan=True, abort_kyuushu_kyuuhai=True, kuikae_ban=True)
HOR = 8

def _kind(code):
    return int(tile2(code).kind)

def _vis(disc, melds, dora):
    vis = [0] * NUM_KINDS
    for lst in disc.values():
        for t in lst:
            vis[tile2(t).kind] += 1
    for _, ts, _s in melds:
        for t in ts:
            vis[tile2(t).kind] += 1
    for t in dora:
        vis[tile2(t).kind] += 1
    return vis

def _val(concealed, melds, dora, sw, rw):
    hand, ms = build_hand2(concealed, melds)
    counts = counts_by_kind(hand.concealed)
    reds = [0] * NUM_KINDS
    for t in concealed:
        if t.endswith('r'):
            reds[tile2(t).kind] += 1
    inds = tuple(tile2(t) for t in dora)
    return counts, ms, reds, inds

def _outlook(counts, nm, reds, ms, inds, vis, sw, rw):
    r = [min(reds[i], counts[i]) for i in range(NUM_KINDS)]
    val = Valuation(rules=RULES, melds=ms, dora_indicators=inds, round_wind=rw, seat_wind=sw,
                    red_fives=tuple(r) if any(r) else ())
    sh = shanten_counts(counts, nm)
    try:
        ol = hand_outlook(counts, nm, HOR, visible=vis, valuation=val, max_distance=min(3, sh))
        win = ol.win[-1]
        pts = ol.points[-1] if ol.points else 0.0
    except Exception:
        win, pts = 0.0, 0.0
    return sh, win, pts

def hand_value(concealed, melds, disc, dora, sw, rw):
    """Оценка руки в покое (13 тайлов, до добора): шантен, шанс победы, очки."""
    counts, ms, reds, inds = _val(concealed, melds, dora, sw, rw)
    vis = _vis(disc, melds, dora)
    sh, win, pts = _outlook(counts, len(ms), reds, ms, inds, vis, sw, rw)
    return dict(shanten=sh, win=win, points=pts, ev=win * pts)

def best_after_call(concealed, melds, disc, dora, sw, rw, forbid, need_below=None):
    """Рука из 14−3·мелдов тайлов уже после взятия: лучший допустимый сброс."""
    counts, ms, reds, inds = _val(concealed, melds, dora, sw, rw)
    vis = _vis(disc, melds, dora)
    nm = len(ms)
    rows = []
    for code in sorted(set(c.replace('r', '') for c in concealed)):
        k = _kind(code)
        if k in forbid:
            continue
        after = list(counts); after[k] -= 1
        sh = shanten_counts(after, nm)
        rows.append((sh, k, after))
    if not rows:
        return None
    bs = min(r[0] for r in rows)
    if need_below is not None and bs >= need_below:
        return None          # взятие не двигает руку: дорогую оценку пропускаем
    best = None
    for sh, k, after in rows:
        if sh > bs:
            continue
        s2, win, pts = _outlook(after, nm, reds, ms, inds, vis, sw, rw)
        row = dict(shanten=sh, win=win, points=pts, ev=win * pts, discard=kname(k))
        if best is None or row['ev'] > best['ev']:
            best = row
    if best['ev'] == 0:
        for sh, k, after in rows:
            if sh != bs + 1:
                continue
            s2, win, pts = _outlook(after, nm, reds, ms, inds, vis, sw, rw)
            if win * pts > best['ev']:
                best = dict(shanten=sh, win=win, points=pts, ev=win * pts, discard=kname(k))
    return best

def options(concealed, tile, from_rel):
    """Возможные взятия: список (вид, использованные из руки, добавленный мелд, запрещённые для сброса виды)."""
    t = tile2(tile)
    k = int(t.kind)
    out = []
    kinds = [_kind(c) for c in concealed]
    if kinds.count(k) >= 2:
        use = []
        for c in concealed:
            if _kind(c) == k and len(use) < 2:
                use.append(c)
        out.append(('pon', use, [tile] + use, {k}))
    if from_rel == 'left' and k < 27:
        n = k % 9; base = k - n
        for a, b in ((-2, -1), (-1, 1), (1, 2)):
            if 0 <= n + a <= 8 and 0 <= n + b <= 8 and (base + n + a) in kinds and (base + n + b) in kinds:
                u1 = next(c for c in concealed if _kind(c) == base + n + a)
                rest = list(concealed); rest.remove(u1)
                u2 = next(c for c in rest if _kind(c) == base + n + b)
                forbid = {k}
                # кувикаэ: нельзя сбрасывать тайл с другого конца секвенции
                lo, hi = min(n + a, n, n + b), max(n + a, n, n + b)
                if n == lo and hi + 1 <= 8:
                    forbid.add(base + hi + 1)
                if n == hi and lo - 1 >= 0:
                    forbid.add(base + lo - 1)
                out.append(('chi', [u1, u2], [tile, u1, u2], forbid))
    return out

SRC_NAME = {'left': 'левый', 'across': 'напротив', 'right': 'правый'}

def evaluate(concealed, melds, disc, dora, sw, rw, tile, from_rel):
    """Сравнение паса и каждого взятия. Сначала дешёвая проверка шантена: тяжёлую оценку считаем,
    только если какое-то взятие двигает руку (или это пон на хонор)."""
    counts, ms, reds, inds = _val(concealed, melds, dora, sw, rw)
    sh_pas = shanten_counts(counts, len(ms))
    res = []
    d2 = {s: list(v) for s, v in disc.items()}
    if tile in d2.get(from_rel, []):
        d2[from_rel].remove(tile)
    honor = _kind(tile) >= 27
    for kind, use, meld_codes, forbid in options(concealed, tile, from_rel):
        rest = list(concealed)
        for u in use:
            rest.remove(u)
        nm = list(melds) + [(kind, meld_codes, SRC_NAME[from_rel])]
        b = best_after_call(rest, nm, d2, dora, sw, rw, forbid, None if honor else sh_pas)
        if b:
            b['kind'] = kind
            b['meld'] = meld_codes
            res.append(b)
    if not res:
        return dict(pas=dict(shanten=sh_pas), options=[])
    pas = hand_value(concealed, melds, disc, dora, sw, rw)
    return dict(pas=pas, options=res)

def decide(r, k=1.0, need_progress=False):
    """Рекомендация: ('pas',None) или (вид, вариант)."""
    best = None
    for o in r['options']:
        if best is None or o['ev'] > best['ev']:
            best = o
    if not best:
        return 'pas', None
    p = r['pas']
    ok = best['ev'] > p['ev'] * k and best['ev'] > 0
    if need_progress and best['shanten'] >= p['shanten']:
        ok = False
    return (best['kind'], best) if ok else ('pas', None)
