"""Минимальная замена OpenCV на одном NumPy (для Android, где cv2 недоступен).
Реализовано только то, что нужно тренеру: matchTemplate(TM_CCOEFF_NORMED), resize(INTER_AREA/любая),
cvtColor(BGR2GRAY), rotate, copyMakeBorder."""
import numpy as np

INTER_AREA = 3
INTER_CUBIC = 2
INTER_LINEAR = 1
COLOR_BGR2GRAY = 6
TM_CCOEFF_NORMED = 5
ROTATE_90_CLOCKWISE = 0
ROTATE_180 = 1
ROTATE_90_COUNTERCLOCKWISE = 2
BORDER_CONSTANT = 0
FONT_HERSHEY_SIMPLEX = 0


def _area_matrix(n_in, n_out):
    """Матрица n_out x n_in: каждый выходной пиксель усредняет перекрытый им отрезок входа."""
    M = np.zeros((n_out, n_in), np.float32)
    scale = n_in / n_out
    for i in range(n_out):
        a, b = i * scale, (i + 1) * scale
        j0, j1 = int(np.floor(a)), int(np.ceil(b))
        for j in range(j0, min(j1, n_in)):
            M[i, j] = max(0.0, min(b, j + 1) - max(a, j))
        s = M[i].sum()
        if s > 0:
            M[i] /= s
    return M


def _lin_matrix(n_in, n_out):
    M = np.zeros((n_out, n_in), np.float32)
    scale = n_in / n_out
    for i in range(n_out):
        x = (i + 0.5) * scale - 0.5
        x0 = int(np.floor(x)); f = x - x0
        a, b = min(max(x0, 0), n_in - 1), min(max(x0 + 1, 0), n_in - 1)
        M[i, a] += 1 - f; M[i, b] += f
    return M


def resize(img, dsize, fx=None, fy=None, interpolation=INTER_AREA):
    h, w = img.shape[:2]
    if dsize is None or (isinstance(dsize, tuple) and dsize == (0, 0)) or dsize == 0:
        nw, nh = max(1, int(round(w * fx))), max(1, int(round(h * fy)))
    else:
        nw, nh = dsize
    mk = _area_matrix if (interpolation == INTER_AREA and (nw <= w and nh <= h)) else _lin_matrix
    Mx, My = mk(w, nw), mk(h, nh)
    f = img.astype(np.float32)
    out = np.tensordot(My, f, axes=(1, 0))            # nh x w (x c)
    out = np.tensordot(out, Mx, axes=(1, 1))          # nh x c x nw  (для 3 каналов) / nh x nw
    if img.ndim == 3:
        out = out.transpose(0, 2, 1)
    if img.dtype == np.uint8:
        out = np.clip(out + 0.5, 0, 255).astype(np.uint8)
    return out


def cvtColor(img, code):
    if code == COLOR_BGR2GRAY:
        f = img.astype(np.float32)
        g = 0.114 * f[..., 0] + 0.587 * f[..., 1] + 0.299 * f[..., 2]
        return np.clip(g + 0.5, 0, 255).astype(np.uint8)
    raise NotImplementedError(code)


def rotate(img, code):
    if code == ROTATE_90_CLOCKWISE:
        return np.ascontiguousarray(np.rot90(img, -1))
    if code == ROTATE_90_COUNTERCLOCKWISE:
        return np.ascontiguousarray(np.rot90(img, 1))
    return np.ascontiguousarray(np.rot90(img, 2))


def copyMakeBorder(img, top, bottom, left, right, borderType, value=0):
    pad = ((top, bottom), (left, right)) + (((0, 0),) if img.ndim == 3 else ())
    return np.pad(img, pad, mode='constant', constant_values=0 if value is None else (value if np.isscalar(value) else 0))


def _box(a, th, tw):
    """Суммы по окнам th x tw (valid) через интегральное изображение."""
    I = np.pad(a, ((1, 0), (1, 0))).cumsum(0).cumsum(1)
    return I[th:, tw:] - I[:-th, tw:] - I[th:, :-tw] + I[:-th, :-tw]


_CACHE = {'img': None, 'val': None}


def _prep(img):
    """Всё, что зависит только от картинки (БПФ каналов и суммы окон), считаем один раз на кадр."""
    c = _CACHE
    if c['img'] is img:
        return c['val']
    I = img.astype(np.float64)
    H, W, C = I.shape
    Fi = [np.fft.rfft2(I[..., k]) for k in range(C)]
    P = np.pad(np.stack([I, I * I], 0), ((0, 0), (1, 0), (1, 0), (0, 0))).cumsum(1).cumsum(2)
    c['img'] = img
    c['val'] = (Fi, P)
    return c['val']


def matchTemplate(img, tpl, method=TM_CCOEFF_NORMED):
    """Нормированная корреляция с вычитанием среднего (как TM_CCOEFF_NORMED у OpenCV, все каналы вместе)."""
    if img.ndim == 2:
        img = img[..., None]; tpl = tpl[..., None]
    H, W, C = img.shape
    th, tw = tpl.shape[:2]
    oh, ow = H - th + 1, W - tw + 1
    Fi, P = _prep(img)
    T = tpl.astype(np.float64)
    Tz = T - T.reshape(-1, C).mean(0)
    tden = np.sqrt((Tz ** 2).sum())
    acc = 0
    for k in range(C):
        Tp = np.zeros((H, W)); Tp[:th, :tw] = Tz[..., k]
        acc = acc + Fi[k] * np.conj(np.fft.rfft2(Tp))
    num = np.fft.irfft2(acc, s=(H, W))[:oh, :ow]
    S = P[:, th:, tw:, :] - P[:, :-th, tw:, :] - P[:, th:, :-tw, :] + P[:, :-th, :-tw, :]
    var = (S[1] - S[0] * S[0] / (th * tw)).sum(-1)
    den = np.sqrt(np.maximum(var, 0)) * tden
    return np.where(den > 1e-6, num / np.maximum(den, 1e-6), 0.0).astype(np.float32)


def imread(path):
    from PIL import Image
    return np.asarray(Image.open(path).convert('RGB'))[..., ::-1].copy()


def imwrite(path, img):
    from PIL import Image
    Image.fromarray(np.ascontiguousarray(img[..., ::-1])).save(path)
    return True


def putText(img, *a, **k):
    return img
