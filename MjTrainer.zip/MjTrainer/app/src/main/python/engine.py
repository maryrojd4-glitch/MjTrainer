"""Движок тренера для Android: кадр экрана -> советы. Только читает пиксели, ничего не нажимает."""
import json
import os
import time
import traceback

import numpy as np

FW, FH = 1600, 720


class Engine:
    def __init__(self, data_dir, log_path):
        os.environ['MJ_DATA'] = data_dir
        self.data_dir = data_dir
        self.log_path = log_path
        import phone
        import tracker
        import advisor
        from jansou.core.tiles import Wind
        self.phone, self.tracker_mod, self.advisor = phone, tracker, advisor
        self.WIND = {'E': Wind.EAST, 'S': Wind.SOUTH, 'W': Wind.WEST, 'N': Wind.NORTH}
        self.O = phone.Observer()
        self.T = tracker.Tracker()
        self.seat, self.rnd = 'E', 'E'
        self.manual = ('E', 'E')
        self.auto = True
        self.replay = False
        self.key = None
        self.last = None          # последний показанный совет (dict)
        self.pending = None
        self.frames = 0
        self.misses = 0
        self.prev_codes = None
        self.last_save = 0
        self.shown = True
        self.call_shown = False
        self.call_last = None
        self.my_riichi = False
        self._rk = None
        self._stick_ref = None
        self._stick_pend = None
        self.riichi_btn_t = 0.0
        self.call_done = -1
        self.prev13 = None

    def set_options(self, seat, rnd, auto=True, mode='game'):
        self.replay = (mode == 'replay')
        self.manual = (seat, rnd)
        self.auto = bool(auto)
        if not self.auto:
            if (seat, rnd) != (self.seat, self.rnd):
                self.key = None
            self.seat, self.rnd = seat, rnd

    def _log(self, rec):
        try:
            with open(self.log_path, 'a', encoding='utf-8') as f:
                f.write(json.dumps(rec, ensure_ascii=False) + '\n')
        except Exception:
            pass

    def _strip_bgr(self, arr, w, h):
        """Только нижняя полоса с рукой: для быстрой проверки «есть ли что советовать»."""
        im = np.zeros((FH, FW, 3), np.uint8)
        im[560:] = arr[560:, :FW, 2::-1]
        return im

    @staticmethod
    def _full_bgr(arr, w, h):
        im = np.ascontiguousarray(arr[..., 2::-1])
        if (w, h) != (FW, FH):
            import cv_np
            im = cv_np.resize(im, (FW, FH))
        return im

    def frame_file(self, path, w, h, wpad):
        """Кадр лежит в файле: RGBA, строки по wpad пикселей (может быть шире w из-за выравнивания)."""
        try:
            arr = np.fromfile(path, np.uint8, count=wpad * h * 4).reshape(h, wpad, 4)[:, :w, :]
            return self._frame_arr(arr, w, h)
        except Exception:
            return self._out('error', 'keep', [], traceback.format_exc(), False)

    def frame(self, rgba, w, h):
        return self._frame_arr(np.frombuffer(rgba, np.uint8).reshape(h, w, 4), w, h)

    # --- ход мысли: рука из 14 читаемых тайлов = твой ход. Ничего не показываем, пока совета нет; не мигаем.
    def _frame_arr(self, arr, w, h):
        t0 = time.time()
        try:
            if w < h:
                return self._out('rotate', 'hide' if self._pop_shown() else 'keep', [], '', False)
            exact = (w, h) == (FW, FH)
            im = self._strip_bgr(arr, w, h) if exact else self._full_bgr(arr, w, h)
            hand = self.O.hand(im)
            codes = [t[0] if t else None for t in hand]
            t_hand = (time.time() - t0) * 1000
            weak = [t for t in hand if t and t[1] < 0.5]
            melds = []
            ok_count = False
            if len(codes) in (14, 11, 8, 5, 2, 13, 10, 7, 4, 1):
                k = len(codes)
                xmin = self.phone.HAND_X0 + self.phone.HAND_PITCH * k + (21 if k in (14, 11, 8, 5, 2) else 0) - 4
                melds = self.O.melds(im, xmin)       # открытые наборы справа внизу, правее руки
            ok_count = melds is not None and len(codes) == 14 - 3 * len(melds)
            if ok_count and None not in codes and not weak:
                self.misses = 0
                key = (tuple(codes), tuple((m[0], tuple(m[1])) for m in melds), self.seat, self.rnd)
                if key == self.key and self.last:
                    return self._out('advice', 'keep', self.last['lines'], self.last['full'], False)
                # взятый тайл едет и мерцает: считаем руку только когда два кадра подряд прочитаны одинаково
                if tuple(codes) != self.prev_codes:
                    self.prev_codes = tuple(codes)
                    return self._out('idle', 'keep', [], '', False)
                if exact:
                    im = self._full_bgr(arr, w, h)
                o = self.O.observe(im)
                if not o['ok']:
                    return self._out('nogame', 'keep', [], '', False)
                o['hand'] = codes
                self._sanitize(o, melds)
                if self.auto:
                    s_auto, r_auto = o.get('seat_round') or (None, None)
                    seat = s_auto or self.manual[0]
                    rnd = r_auto or self.manual[1]
                    self.seat, self.rnd = seat, rnd
                key = (tuple(codes), tuple((m[0], tuple(m[1])) for m in melds), self.seat, self.rnd)
                new = self.T.update(o)
                self._stick_update(im)
                if self.my_riichi:
                    return self._hide_call() or self._out('idle', 'hide' if self._pop_shown() else 'keep', [], '', False)
                for e in new:
                    if e[1] == 'me' and self.pending and not self.replay:
                        p = self.pending
                        p['actual'] = e[2]
                        top = p['advice']['top']
                        p['matched_top1'] = bool(top and top[0]['code'] == e[2].replace('r', ''))
                        self._log(p)
                        self.pending = None
                t_obs = (time.time() - t0) * 1000
                adv = self.advisor
                r = adv.advise4(o['hand'], melds, o, self.T, seat_wind=self.WIND[self.seat], round_wind=self.WIND[self.rnd])
                self._tiebreak(r, o)
                t_adv = (time.time() - t0) * 1000
                dora = ' '.join(adv.kname(int(adv.tile2(t).kind)) for t in o['dora'])
                wn = {'E': 'Восток', 'S': 'Юг', 'W': 'Запад', 'N': 'Север'}
                head = 'Ты: %s, раунд: %s. Стена %s, дора-индикатор: %s' % (wn[self.seat], wn[self.rnd], o['wall'], dora or '?')
                if self.T.riichi:
                    names = {'left': 'слева', 'right': 'справа', 'across': 'напротив', 'me': 'ты'}
                    head += '\nриичи: ' + ', '.join(names.get(s, s) for s in self.T.riichi)
                full = head + '\n\n' + adv.explain4(r, self.T)
                lst = r['fold'] if r['mode'] == 'fold' else r['attack3']
                if self.replay:
                    lines = self._panel(r, adv.explain4(r, self.T))
                else:
                    lines = [str(lst[0]['tile'])] if lst else []
                self.key = key
                self.shown = True
                self.last = dict(lines=lines, full=full, fold=(r['mode'] == 'fold'))
                rec = dict(t=time.strftime('%H:%M:%S'), hand=o['hand'], dora=o['dora'], wall=o['wall'],
                           riichi=list(self.T.riichi), disc=o['disc'], advice=adv.summary(r),
                           seat=self.seat, round=self.rnd, mode='replay' if self.replay else 'game',
                           ms=dict(hand=round(t_hand), obs=round(t_obs), adv=round(t_adv)))
                if self.replay:
                    self._log(rec)
                else:
                    self.pending = rec
                return self._out('advice', 'show', lines, full, True, ms=t_adv, fold=(r['mode'] == 'fold'))
            if (not self.replay) and melds is not None and len(codes) in (13, 10, 7, 4, 1) and len(codes) == 13 - 3 * len(melds) \
                    and None not in codes and not weak:
                res = self._call_frame(arr, im, w, h, exact, codes, melds)
                if res is not None:
                    return res
            # не 14 тайлов: либо не твой ход, либо анимация. Прячем только после нескольких кадров подряд.
            self.misses += 1
            self.prev_codes = None
            if len(codes) in (14, 11, 8, 5, 2) and time.time() - getattr(self, 'last_miss_log', 0) > 3:
                self.last_miss_log = time.time()
                self._log(dict(t=time.strftime('%H:%M:%S'), kind='drop', n=len(codes), none=sum(c is None for c in codes),
                               weak=len(weak), melds=None if melds is None else len(melds), hand=codes))
            if len(codes) in (14, 11, 8, 5, 2) and not ok_count and time.time() - self.last_save > 3:
                self.last_save = time.time()
                return self._out('meld?', 'keep', [], 'Рука из %d тайлов, наборов прочитано: %s' % (len(codes), 'нет' if melds is None else len(melds)), True)
            if self.misses >= 3 and self.shown:
                self.shown = False
                self.key = None
                self.last = None
                return self._out('idle', 'hide', [], '', False, ms=(time.time() - t0) * 1000)
            return self._out('idle', 'keep', [], '', False, ms=(time.time() - t0) * 1000)
        except Exception:
            return self._out('error', 'keep', [], traceback.format_exc(), False)

    def _call_frame(self, arr, im, w, h, exact, codes, melds):
        """Рука из 13-3m тайлов: ждём сброс соперника и решаем, стоит ли брать (пон/чи)."""
        t0 = time.time()
        if tuple(codes) != getattr(self, 'prev13', None):
            self.prev13 = tuple(codes)
            return None
        im = self._full_bgr(arr, w, h)
        if not self._skip_visible(im):
            return self._hide_call()
        o = self.O.observe(im)
        if not o['ok']:
            return None
        o['hand'] = codes
        self._sanitize(o, melds)
        if self.auto:
            s_auto, r_auto = o.get('seat_round') or (None, None)
            self.seat = s_auto or self.manual[0]
            self.rnd = r_auto or self.manual[1]
        self.T.update(o)
        self._stick_update(im)
        if self.my_riichi:
            return self._hide_call()
        ev = self.T.events
        if not ev or ev[-1][1] == 'me':
            return None
        seq, seat, tile = ev[-1]
        if seq == getattr(self, 'call_done', -1):
            if self.call_shown and self.call_last:
                return self._out('advice', 'keep', self.call_last['lines'], self.call_last['full'], False)
            return None
        self.call_done = seq
        import calladv, callmodel
        adv = self.advisor
        disc = {s_: list(v) for s_, v in o['disc'].items()}
        r = calladv.evaluate(codes, melds, disc, o['dora'], self.WIND[self.seat], self.WIND[self.rnd], tile, seat)
        if not r['options']:
            self._log(dict(t=time.strftime('%H:%M:%S'), kind='call-skip', tile=tile, frm=seat, pas=r['pas'], ms=round((time.time() - t0) * 1000)))
            return self._hide_call()
        best = max(r['options'], key=lambda x: (x['points'] > 0, x['ev']))
        ndraw = max(0, 70 - (o['wall'] or 70))
        honor = tile[1] == 'z'
        nri = len([s_ for s_ in self.T.riichi if s_ != 'me'])
        p = callmodel.prob(r['pas'], best, len(melds) > 0, ndraw, nri, honor)
        rec = dict(t=time.strftime('%H:%M:%S'), kind='call', tile=tile, frm=seat, hand=codes, melds=[list(m) for m in melds],
                   dora=o['dora'], pas=r['pas'], best={k: v for k, v in best.items()}, p=round(p, 3), mode='game',
                   ms=round((time.time() - t0) * 1000))
        self._log(rec)
        if p < callmodel.THR:
            return self._hide_call()
        name = 'Пон' if best['kind'] == 'pon' else 'Чи'
        sets = ' '.join(adv.kname(int(adv.tile2(c).kind)) for c in best['meld'])
        line = '%s, потом сбросить %s' % (name, best['discard'])
        full = ('Взять %s: %s\nПосле взятия сбросить %s.\nШантен %d → %d. Шанс собрать %.0f%% → %.0f%%, цена руки %d → %d.\n(уверенность совета %.0f%%)' %
                (name.lower(), sets, best['discard'], r['pas']['shanten'], best['shanten'], 100 * r['pas']['win'], 100 * best['win'],
                 r['pas']['points'], best['points'], 100 * p))
        self.call_last = dict(lines=[line], full=full)
        self.call_shown = True
        self.shown = True
        self.key = None
        return self._out('advice', 'show', [line], full, True, ms=(time.time() - t0) * 1000)

    def _ncc(self, name, im, box, thr):
        t = getattr(self, name, None)
        if t is None:
            t = np.load(os.path.join(self.data_dir, name[1:] + '.npy')).astype(np.float32)
            t = t - t.mean()
            setattr(self, name, t)
        y0, y1, x0, x1 = box
        g = im[y0:y1, x0:x1].astype(np.float32).mean(axis=2)
        g = g - g.mean()
        den = float(np.sqrt((g * g).sum() * (t * t).sum()))
        return den > 0 and float((g * t).sum()) / den > thr

    def _stick_update(self, im):
        """Риичи, которое трекер не видит по повёрнутому тайлу: считаем по счётчику палочек в углу.
        Своё риичи (перед этим была кнопка «Riichi») выключает советы до конца раздачи; иначе — риичи напротив."""
        now = time.time()
        rk = getattr(self.T, 'round_no', None)
        reg = im[92:116, 60:215].astype(np.int16)
        if rk != self._rk or self._stick_ref is None:
            self._rk, self._stick_ref, self.my_riichi, self._stick_pend, self.riichi_btn_t = rk, reg, False, None, 0.0
        if self._ncc('_riichibtn', im, (515, 580, 770, 930), 0.8):
            self.riichi_btn_t = now
        changed = float((np.abs(reg - self._stick_ref).max(axis=2) > 40).mean()) > 0.02
        if changed and self._stick_pend is None:
            self._stick_pend = (now, now - self.riichi_btn_t < 90)
        if self._stick_pend and now - self._stick_pend[0] > 6:
            t0, mine = self._stick_pend
            self._stick_pend = None
            self._stick_ref = reg
            if mine:
                self.my_riichi = True
                self._log(dict(t=time.strftime('%H:%M:%S'), kind='riichi', who='me'))
            elif not any(s in self.T.riichi for s in ('left', 'right')):
                self.T.riichi['across'] = max(len(self.T.events) - 1, 0)
                self._log(dict(t=time.strftime('%H:%M:%S'), kind='riichi', who='across'))

    def _skip_visible(self, im):
        """Кнопка «Skip» (пас) видна: значит соперник сбросил тайл и можно брать."""
        if getattr(self, '_skip_t', None) is None:
            self._skip_t = np.load(os.path.join(self.data_dir, 'skip.npy')).astype(np.float32)
            self._skip_t = (self._skip_t - self._skip_t.mean()).ravel()
        g = im[525:585, 965:1090].astype(np.float32).mean(axis=2)
        g = (g - g.mean()).ravel()
        den = float(np.sqrt((g * g).sum() * (self._skip_t * self._skip_t).sum()))
        return den > 0 and float((g * self._skip_t).sum()) / den > 0.8

    def _hide_call(self):
        self.call_last = None
        if self.call_shown:
            self.call_shown = False
            self.shown = False
            return self._out('idle', 'hide', [], '', False)
        return None

    def _pop_shown(self):
        v = self.shown
        self.shown = False
        return v

    def _sanitize(self, o, melds):
        """Тайлов одного вида не больше четырёх: лишнее — ошибка распознавания в сбросах или доре, их убираем."""
        adv = self.advisor
        cnt = {}

        def add(t):
            k = int(adv.tile2(t).kind)
            cnt[k] = cnt.get(k, 0) + 1
            return cnt[k]
        for t in o['hand']:
            add(t)
        for m in melds:
            for t in m[1]:
                add(t)
        for t in o['dora']:
            add(t)
        for seat in o['disc']:
            keep = []
            for t in o['disc'][seat]:
                if cnt.get(int(adv.tile2(t).kind), 0) < 4:
                    add(t)
                    keep.append(t)
            o['disc'][seat] = keep
        for t in list(o['dora']):
            if cnt.get(int(adv.tile2(t).kind), 0) > 4:
                o['dora'].remove(t)
                cnt[int(adv.tile2(t).kind)] -= 1

    # --- порядок среди почти равных вариантов: нужные тайлы последними, ненужные первыми
    def _tiebreak(self, r, o):
        if r['mode'] == 'fold' or not r['attack3']:
            return
        adv = self.advisor
        seat_k = {'E': 27, 'S': 28, 'W': 29, 'N': 30}[self.seat]
        round_k = {'E': 27, 'S': 28, 'W': 29, 'N': 30}[self.rnd]
        yaku_h = {31, 32, 33, seat_k, round_k}
        vis = {}
        for lst in o['disc'].values():
            for t in lst:
                k = int(adv.tile2(t).kind)
                vis[k] = vis.get(k, 0) + 1
        cnt = {}
        for t in o['hand']:
            k = int(adv.tile2(t).kind)
            cnt[k] = cnt.get(k, 0) + 1
        dora_k = set()
        for t in o['dora']:
            k = int(adv.tile2(t).kind)
            dora_k.add(k + 1 if k < 27 and k % 9 != 8 else (k - 8 if k < 27 else (27 if k == 30 else 31 if k == 33 else k + 1)))
        rows = {x['tile']: x for x in r['rows3']}

        def prio(code):
            k = int(adv.tile2(code).kind)
            if k in dora_k or code.endswith('r'):
                return 5
            c = cnt.get(k, 0)
            if c >= 2:
                return 4
            if k >= 27:
                if k in yaku_h:
                    return 7 if (4 - vis.get(k, 0) - c) < 2 else 4
                return 2
            n = k % 9
            lonely = not any(0 <= n + d <= 8 and cnt.get(k + d, 0) > 0 for d in (-2, -1, 1, 2))
            if n in (0, 8):
                return 1 if lonely else 4
            if n in (1, 7):
                return 3 if lonely else 5
            return 7
        top = r['attack3'][0]
        ty = rows.get(top['tile'], top)
        best = (ty['shanten'], ty.get('ukeire') or 0, ty.get('ev', 0) or 0)

        def close(x):
            y = rows.get(x['tile'], x)
            if y['shanten'] != best[0]:
                return False
            if best[2] > 0:
                return (y.get('ev', 0) or 0) >= 0.85 * best[2]
            return (y.get('ukeire') or 0) >= 0.85 * best[1]
        group = [x for x in r['attack3'] if close(x)]
        rest = [x for x in r['attack3'] if not close(x)]

        def code_of(x):
            y = rows.get(x['tile'], x)
            return y.get('code') or str(x['tile'])
        group.sort(key=lambda x: prio(code_of(x)))
        r['attack3'] = group + rest

    @staticmethod
    def _out(status, act, lines, full, save, ms=0, fold=False):
        return json.dumps(dict(status=status, act=act, lines=lines, full=full, save=save, ms=round(ms), fold=fold), ensure_ascii=False)

    @staticmethod
    def _panel(r, explain):
        """Короткий текст для панели поверх игры."""
        lst = r['fold'] if r['mode'] == 'fold' else r['attack3']
        rows3 = {x['tile']: x for x in r['rows3']}
        out = []
        if not lst:
            return ['Нет вариантов']
        a = lst[0]
        y = rows3.get(a['tile'], a)

        def sh(v):
            return 'тенпай' if v == 0 else ('готова' if v < 0 else '%d-шант' % v)
        out.append(('ЗАЩИТА: сбросить ' if r['mode'] == 'fold' else 'Сбросить ') + str(a['tile']))
        info = sh(y['shanten'])
        if r['mode'] == 'fold':
            info += ', опасность %.1f%%' % a.get('risk', 0)
        else:
            info += ', принимает %s' % y.get('ukeire')
            if y.get('points'):
                info += ', шанс %.0f%%' % (y['win'] * 100)
        out.append(info)
        alts = [str(x['tile']) for x in lst[1:3]]
        if alts:
            out.append('Также: ' + ', '.join(alts))
        for line in explain.split('\n'):
            if line.startswith('Почему'):
                out.append(line)
                break
        return out
