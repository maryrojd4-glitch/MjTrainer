"""Чтение стола Mahjong Soul на телефоне (кадр 1600x720, альбомная ориентация).
Всё построено на NumPy: окна сравниваются с шаблонами одним матричным умножением."""
import os
import numpy as np
try:
    import cv2
except ImportError:
    import cv_np as cv2
import scan_hand

HERE = os.path.dirname(os.path.abspath(__file__))
FW, FH = 1600, 720

# ---------------------------------------------------------------- шаблоны
def _gray(a):
    a = a.astype(np.float32)
    return 0.114 * a[..., 0] + 0.587 * a[..., 1] + 0.299 * a[..., 2]


class Bank:
    """Набор шаблонов одного размера (серые, с вычтенным средним и единичной нормой)."""
    def __init__(self, items, w, h):
        self.w, self.h = w, h
        self.keys, rows = [], []
        for key, img in items:
            g = _gray(img)
            g = g - g.mean()
            n = np.sqrt((g * g).sum())
            if n < 1e-3:
                continue
            self.keys.append(key)
            rows.append((g / n).ravel())
        self.M = np.array(rows, np.float32)

    def match(self, gray_patch, dx, dy):
        """gray_patch: окно размера (h+2*dy, w+2*dx). Возвращает лучший счёт по каждому шаблону."""
        h, w = self.h, self.w
        sh = np.lib.stride_tricks.sliding_window_view(gray_patch, (h, w))   # (2dy+1, 2dx+1, h, w)
        W = sh.reshape(-1, h * w).astype(np.float32)
        W = W - W.mean(1, keepdims=True)
        n = np.sqrt((W * W).sum(1, keepdims=True))
        W = W / np.maximum(n, 1e-3)
        S = self.M @ W.T                                   # (шаблонов, сдвигов)
        return S.max(1), S.argmax(1)


def _variants(base_imgs, sizes, rot=None, crops=((0, None),)):
    """base_imgs: {код: картинка тайла 45x68}. Возвращает {размер: [(код, картинка)]}"""
    out = {s: [] for s in sizes}
    for k, t in base_imgs.items():
        for a, b in crops:
            c = t[a:b]
            if rot is not None:
                c = cv2.rotate(c, rot)
            for s in sizes:
                out[s].append((k, cv2.resize(c, s, interpolation=cv2.INTER_AREA)))
    return out


def best_of(banks, gray_win, dx, dy, topn=2):
    """Лучший код среди всех банков (разные размеры шаблонов)."""
    sc = {}
    for b in banks:
        if gray_win.shape[0] < b.h or gray_win.shape[1] < b.w:
            continue
        s, _ = b.match(gray_win[: b.h + 2 * dy, : b.w + 2 * dx], dx, dy)
        for k, v in zip(b.keys, s):
            if v > sc.get(k, -2):
                sc[k] = float(v)
    top = sorted(sc.items(), key=lambda kv: -kv[1])[:topn]
    return top


def red_fraction(c):
    c = c.astype(int)
    b, g, r = c[..., 0], c[..., 1], c[..., 2]
    return float(((r > 120) & (r - g > 55) & (r - b > 55)).mean())


def blank(face_gray):
    return face_gray.mean() > 150 and float((face_gray < 150).mean()) < 0.10


def tile_present(face):
    f = face.astype(int)
    b, g, r = f[..., 0], f[..., 1], f[..., 2]
    return (((abs(r - b) < 28) & (abs(g - b) < 28)).mean() > 0.33) or ((((r + g + b) / 3) > 170).mean() > 0.30)


# ---------------------------------------------------------------- геометрия (подогнана по кадрам)
# свои сбросы: три ряда слева направо
OWN_ROWS = [(673.0, 41.5, 362), (670.0, 42.1, 404), (666.0, 42.8, 447)]
OWN_W, OWN_H = 39, 38
# напротив: ряды от ближнего, справа налево; тайлы перевёрнуты на 180°
ACR_ROWS = [(872.0, 36.4, 162, 32), (872.0, 35.4, 132, 30), (872.0, 34.5, 102, 28), (872.0, 33.8, 74, 26)]
ACR_W = 36
# левый игрок: колонка 0 ближе к центру, колонки идут влево; в колонке сверху вниз; тайл повёрнут на 90° по часовой
LEFT_Y0, LEFT_DY = 194.0, 25.6
# правый игрок: колонка 0 ближе к центру, колонки идут вправо; в колонке снизу вверх
RIGHT_Y0, RIGHT_DY = 195.5, 25.9
SIDE_W, SIDE_H = 47, 24


def left_xy(c, r):
    return 627.5 - 2.6 * r - c * (46.5 + 1.1 * r), LEFT_Y0 + LEFT_DY * r


def right_xy(c, r):
    return 919.0 + 2.0 * r + c * (50.0 + 1.2 * r), RIGHT_Y0 + RIGHT_DY * r


# рука
HAND_X0, HAND_PITCH, HAND_Y = 308.0, 63.2, 614
HAND_W, HAND_H = 62, 94
# дора
DORA_X0, DORA_PITCH, DORA_Y, DORA_W, DORA_H = 46.0, 37.5, 31, 35, 51
# счётчик стены (бирюзовые цифры «×61»)
WALL_BOX = (772, 835, 284, 306)
TURN_BOX = {'me': (765, 835, 330, 344), 'across': (765, 835, 214, 232),
            'left': (706, 730, 260, 306), 'right': (868, 892, 256, 304)}


SEAT_BOX = {'me': (690, 728, 330, 356), 'right': (872, 910, 328, 356), 'across': (866, 904, 212, 236), 'left': (700, 740, 212, 236)}
# ветер игрока с красной меткой «Е» (дилер) -> твой ветер: me=E, right(дилер справа)=N, across=W, left=S
SEAT_FROM_DEALER = {'me': 'E', 'right': 'N', 'across': 'W', 'left': 'S'}


class Observer:
    def __init__(self):
        base = dict(scan_hand.TPL)
        self.base = base
        blank_key = '5z'
        self.hand_bank = Bank(self._hand_items(base), 31, 47)
        s_own = [(OWN_W - 1, OWN_H - 1), (OWN_W, OWN_H), (OWN_W + 1, OWN_H + 1)]
        v = _variants(base, s_own, crops=((4, 58),))
        self.own = [Bank(v[s], s[0], s[1]) for s in s_own]
        s_acr = [(ACR_W - 1, 29), (ACR_W, 31), (ACR_W, 33)]
        v = _variants(base, s_acr, rot=cv2.ROTATE_180, crops=((4, 58),))
        self.acr = [Bank(v[s], s[0], s[1]) for s in s_acr]
        s_sd = [(SIDE_W - 1, SIDE_H - 1), (SIDE_W, SIDE_H), (SIDE_W + 1, SIDE_H)]
        v = _variants(base, s_sd, rot=cv2.ROTATE_90_CLOCKWISE, crops=((4, 58),))
        self.left = [Bank(v[s], s[0], s[1]) for s in s_sd]
        v = _variants(base, s_sd, rot=cv2.ROTATE_90_COUNTERCLOCKWISE, crops=((4, 58),))
        self.right = [Bank(v[s], s[0], s[1]) for s in s_sd]
        # тайл риичи у боковых игроков: левый — прямой, правый — перевёрнутый на 180°
        s_ri = [(32, 30), (34, 30), (36, 30)]
        v = _variants(base, s_ri, rot=None, crops=((4, 58),))
        self.left_ri = [Bank(v[s], s[0], s[1]) for s in s_ri]
        v = _variants(base, s_ri, rot=cv2.ROTATE_180, crops=((4, 58),))
        self.right_ri = [Bank(v[s], s[0], s[1]) for s in s_ri]
        s_d = [(DORA_W - 3, DORA_H - 5), (DORA_W - 2, DORA_H - 4), (DORA_W - 1, DORA_H - 3)]
        v = _variants(base, s_d, crops=((2, 62), (6, 58)))
        self.dora = [Bank(v[s], s[0], s[1]) for s in s_d]
        # открытые наборы справа внизу: прямой тайл 48 px шириной, повёрнутый 60 px
        s_mu = [(40, 32), (42, 34), (44, 36)]
        v = _variants(base, s_mu, crops=((10, 50),))
        self.meld_up = [Bank(v[s], s[0], s[1]) for s in s_mu]
        s_mr = [(50, 35), (52, 36), (54, 37)]
        v = _variants(base, s_mr, rot=cv2.ROTATE_90_CLOCKWISE, crops=((4, 58),))
        self.meld_cw = [Bank(v[s], s[0], s[1]) for s in s_mr]
        v = _variants(base, s_mr, rot=cv2.ROTATE_90_COUNTERCLOCKWISE, crops=((4, 58),))
        self.meld_ccw = [Bank(v[s], s[0], s[1]) for s in s_mr]
        import wall as _w
        self.WT = _w.build()
        self.cache = {}

    @staticmethod
    def _hand_items(base):
        items = []
        for k, t in base.items():
            items.append((k, cv2.resize(t, (31, 47), interpolation=cv2.INTER_AREA)))
        return items

    # ------------------------------------------------------------ кэш по содержимому окна
    def _cached(self, tag, win, fn):
        key = (tag, win.shape, win[::3, ::3].tobytes())
        if key in self.cache:
            return self.cache[key]
        if len(self.cache) > 4000:
            self.cache.clear()
        r = fn()
        self.cache[key] = r
        return r

    def _classify(self, im, g, x, y, w, h, banks, tag, pad=5, padv=None):
        padv = pad if padv is None else padv
        x0, y0 = int(round(x)) - pad, int(round(y)) - padv
        if x0 < 0 or y0 < 0 or x0 + w + 2 * pad > FW or y0 + h + 2 * padv > FH:
            return None
        win = im[y0:y0 + h + 2 * padv, x0:x0 + w + 2 * pad]
        face = im[int(round(y)) + 3:int(round(y)) + h - 3, int(round(x)) + 3:int(round(x)) + w - 3]
        if face.size == 0 or not tile_present(face):
            return None

        def run():
            fg = _gray(face)
            if blank(fg):
                return ('5z', 1.0, 1.0)
            top = best_of(banks, g[y0:y0 + h + 2 * padv, x0:x0 + w + 2 * pad], pad, padv)
            return (top[0][0], top[0][1], top[0][1] - top[1][1])
        key = (tag, face.shape, (face[::2, ::2] >> 3).tobytes())
        if key in self.cache:
            return self.cache[key]
        if len(self.cache) > 6000:
            self.cache.clear()
        r = run()
        self.cache[key] = r
        return r

    # ------------------------------------------------------------ зоны
    def mine(self, im, g):
        out = []
        for r, (x0, p, y) in enumerate(OWN_ROWS):
            for c in range(6):
                t = self._classify(im, g, x0 + p * c, y, OWN_W, OWN_H, self.own, 'own', pad=5)
                if t is None:
                    return out
                out.append(t)
        return out

    def across(self, im, g):
        out = []
        for r, (x0, p, y, h) in enumerate(ACR_ROWS):
            for c in range(6):
                t = self._classify(im, g, x0 - p * c, y, ACR_W, h, self.acr, 'acr%d' % r, pad=5)
                if t is None:
                    return out
                out.append(t)
        return out

    def side(self, im, g, seat):
        pos = left_xy if seat == 'L' else right_xy
        N, RI = (self.left, self.left_ri) if seat == 'L' else (self.right, self.right_ri)
        out, ri = [], None
        order = [(c, r) for c in range(3) for r in (range(6) if seat == 'L' else range(5, -1, -1))]
        shift = {}
        for c, r in order:
            x, y = pos(c, r)
            sy = shift.get(c, 0.0)
            y = y + (sy if seat == 'L' else -sy)
            t = self._classify(im, g, x, y, SIDE_W, SIDE_H, N, 'sd' + seat, pad=6, padv=11)
            if t is None:
                # возможно, это тайл риичи (он выше обычного)
                t = None
                break
            tr = self._classify_ri(im, g, x, y, RI, seat)
            if tr is not None and tr[1] > t[1] + 0.1 and tr[1] > 0.55:
                ri = len(out)
                out.append(tr)
                shift[c] = shift.get(c, 0.0) + 10.0
            else:
                out.append(t)
        return out, ri

    def _classify_ri(self, im, g, x, y, banks, seat):
        w, h = banks[0].w, banks[0].h
        x0, y0 = int(round(x)) + 3 - 6, int(round(y)) - 6 - 6
        if x0 < 0 or y0 < 0 or x0 + w + 12 > FW or y0 + h + 12 > FH:
            return None
        top = best_of(banks, g[y0:y0 + h + 12, x0:x0 + w + 12], 6, 6)
        return (top[0][0], top[0][1], top[0][1] - top[1][1])

    def dora_read(self, im, g):
        out = []
        for i in range(5):
            x = DORA_X0 + DORA_PITCH * i
            f = im[DORA_Y + 5:DORA_Y + DORA_H - 5, int(x) + 3:int(x) + DORA_W - 3].astype(int)
            b, gg, r = f[..., 0], f[..., 1], f[..., 2]
            back = ((b - r > 60) & (b > 150)).mean()
            light = (((r + gg + b) / 3) > 170).mean()
            if not (back < 0.5 and light > 0.3):
                out.append(None)
                continue
            fg = _gray(f)
            if (fg < 150).mean() < 0.1:
                out.append(('5z', 1, 1))
                continue
            x0, y0 = int(x) - 4, DORA_Y - 4
            top = best_of(self.dora, g[y0:y0 + DORA_H + 8, x0:x0 + DORA_W + 8], 4, 4)
            out.append((top[0][0], round(top[0][1], 2), round(top[0][1] - top[1][1], 2)))
        return out

    # ------------------------------------------------------------ стена, ход, счётчики
    @staticmethod
    def teal(im):
        x0, x1, y0, y1 = WALL_BOX
        reg = im[y0:y1, x0:x1].astype(int)
        b, g, r = reg[..., 0], reg[..., 1], reg[..., 2]
        return (g > 105) & (b > 105) & (g - r > 35)

    def wall(self, im):
        m = self.teal(im)
        if m.sum() < 40:
            return None
        cols = m.any(0)
        runs, s = [], None
        for i, v in enumerate(cols):
            if v and s is None:
                s = i
            if not v and s is not None:
                runs.append((s, i - 1)); s = None
        if s is not None:
            runs.append((s, len(cols) - 1))
        runs = [r for r in runs if r[1] - r[0] >= 1]
        if len(runs) < 3:
            return None
        s_ = ''
        for a, b in runs[-2:]:
            sub = m[:, a:b + 1].astype(np.uint8) * 255
            ys = np.where(sub.any(1))[0]
            sub = sub[ys[0]:ys[-1] + 1]
            d = cv2.resize(sub, (8, 12), interpolation=cv2.INTER_AREA).astype(float) / 255
            s_ += min(self.WT, key=lambda c: ((self.WT[c] - d) ** 2).sum())
        return int(s_)

    @staticmethod
    def turn(im):
        im = im.astype(int)
        out = {}
        for k, (x0, x1, y0, y1) in TURN_BOX.items():
            reg = im[y0:y1, x0:x1]
            b, g, r = reg[..., 0], reg[..., 1], reg[..., 2]
            out[k] = int(((r > 170) & (g > 165) & (b < 130) & (abs(r - g) < 35)).sum())
        k = max(out, key=out.get)
        return (k if out[k] >= 25 else None), out

    # ------------------------------------------------------------ рука
    @staticmethod
    def _kind(code):
        n = int(code[0])
        return {'m': 0, 'p': 9, 's': 18, 'z': 27}[code[1]] + n - 1

    def hand(self, im):
        """Рука по фиксированным слотам -> список (код, уверенность) или None.
        Тайлы в руке всегда лежат по возрастанию, поэтому для 13 тайлов выбирается самая вероятная
        последовательность, не нарушающая порядок. Это исправляет единичные ошибки (блик, соседний тайл).
        Взятый тайл (14-й) стоит отдельно и порядку не подчиняется."""
        g = _gray(im[600:720, 290:1240])
        half = cv2.resize(g, (g.shape[1] // 2, g.shape[0] // 2), interpolation=cv2.INTER_AREA)
        cands = []
        for i in range(13):
            x = HAND_X0 + HAND_PITCH * i
            if not self._held_present(im, x):
                break
            cands.append(self._hand_cands(half, im, x))
        n = len(cands)
        res = self._decode_sorted(cands)
        # взятый тайл стоит после зазора: сдвиг ровно на +21 px от следующего слота
        xd = HAND_X0 + HAND_PITCH * n + 21
        if n >= 1 and self._slot_present(im, xd):
            c = self._hand_cands(half, im, xd, pad=10)
            res.append(c[0] if c else None)
        return res

    @staticmethod
    def _held_present(im, x):
        """Тайл на своём слоте: светлая левая полоса грани (на месте взятого тайла со сдвигом +21 она тёмная)."""
        tx = int(x)
        strip = im[HAND_Y + 20:HAND_Y + 80, tx + 3:tx + 15]
        return strip.size > 0 and strip.mean() > 100 and tile_present(strip)

    def _decode_sorted(self, cands):
        """Динамическое программирование: максимум суммы счётов при неубывающем порядке тайлов."""
        n = len(cands)
        if n == 0:
            return []
        INF = -1e9
        opts = []
        for c in cands:
            o = [(self._kind(code), code, sc) for code, sc in c] if c else []
            o.append((-1, None, 0.0))      # нечитаемый слот: подходит на любое место
            opts.append(o)
        best = [[INF] * len(o) for o in opts]
        back = [[-1] * len(o) for o in opts]
        for j, (k, code, sc) in enumerate(opts[0]):
            best[0][j] = sc
        for i in range(1, n):
            for j, (k, code, sc) in enumerate(opts[i]):
                for jj, (k0, c0, s0) in enumerate(opts[i - 1]):
                    if best[i - 1][jj] == INF:
                        continue
                    kk = k0
                    if k0 == -1:                       # у неизвестного слота порог берём от предыдущего известного
                        kk = -1
                    if k != -1 and kk != -1 and k < kk:
                        continue
                    v = best[i - 1][jj] + sc
                    if v > best[i][j]:
                        best[i][j] = v
                        back[i][j] = jj
        j = max(range(len(opts[-1])), key=lambda t: best[-1][t])
        out = [None] * n
        for i in range(n - 1, -1, -1):
            k, code, sc = opts[i][j]
            out[i] = (code, sc) if code else None
            j = back[i][j]
            if j < 0 and i > 0:
                break
        return out

    @staticmethod
    def _slot_present(im, x):
        tx = int(x)
        if tx + 58 > FW:
            return False
        face = im[HAND_Y + 6:HAND_Y + 84, tx + 4:tx + 58]
        # пустое место в руке тёмное (яркость ~70–90), грань тайла светлая (>110 даже при затемнении кадра)
        return face.mean() > 100 and tile_present(face)

    def _hand_cands(self, half, im, x, pad=6):
        """До 4 лучших кодов для слота: [(код, счёт)], лучший первым."""
        px = int((x - 290) / 2) - pad
        py = int((HAND_Y - 600) / 2) - 4
        win = half[max(0, py):py + 47 + 8, max(0, px):px + 31 + 2 * pad]
        if win.shape[0] < 47 or win.shape[1] < 31:
            return []
        tx = int(x)
        face = im[HAND_Y + 26:HAND_Y + 72, tx + 4:tx + 58]
        rf = red_fraction(face)
        key = ('hand', win.shape, win[::2, ::2].astype(np.uint8).tobytes(), round(rf, 2))
        if key in self.cache:
            return self.cache[key]
        if blank(_gray(im[HAND_Y + 10:HAND_Y + 80, tx + 6:tx + 56])):
            r = [('5z', 1.0)]
        else:
            s, _ = self.hand_bank.match(win, 0, 0)
            order = np.argsort(-s)[:6]
            seen = {}
            for j in order:
                code = self.hand_bank.keys[int(j)]
                if code in ('3p', '5p', '7p') and rf > 0.10:
                    code = '5pr'
                elif code in ('4s', '5s', '6s') and rf > 0.10:
                    code = '5sr'
                elif code in ('4m', '5m', '6m') and rf > 0.13:
                    code = '5mr'
                if float(s[j]) > seen.get(code, -2):
                    seen[code] = float(s[j])
            r = sorted(seen.items(), key=lambda kv: -kv[1])[:4]
            r = [(c, v) for c, v in r if v >= 0.3]
        self.cache[key] = r
        return r

    # ------------------------------------------------------------ свои открытые наборы
    MELD_UP_W, MELD_ROT_W = 48, 60
    MELD_UP_Y, MELD_ROT_Y = 634, 646

    @staticmethod
    def meld_extent(im):
        """Правая группа светлых тайлов в полосе наборов: (левый край, правый край) или None.
        Тайлы руки тоже светлые, но они длиннее: у них светлая грань доходит до y≈700, у набора кончается на ≈692."""
        reg = im[644:690, 560:1420].astype(np.int16)
        blue = ((reg[..., 0] - reg[..., 2] > 40) & (reg[..., 0] > 110)).mean(0) > 0.6
        # жёлтые вспышки анимации (R сильно выше B) гранью тайла не считаем
        face = (reg.mean(2) > 140) & ((reg[..., 2] - reg[..., 0]) < 45)
        bright = (face.mean(0) > 0.30) | blue
        low = im[698:704, 560:1420].astype(np.int16).mean(2).mean(0) < 120
        ok = bright & low
        cols = np.where(ok)[0]
        if len(cols) < 40:
            return None
        # группы столбцов с зазором не шире 14 px; берём самую правую группу шириной >= 100 (одиночные блики не в счёт)
        groups = []
        gs = gp = int(cols[0])
        for c in cols[1:]:
            c = int(c)
            if c - gp > 14:
                groups.append((gs, gp))
                gs = c
            gp = c
        groups.append((gs, gp))
        groups = [g for g in groups if g[1] - g[0] >= 100]
        if not groups:
            return None
        L, R = groups[-1]
        return L + 560, R + 560 + 1

    def _meld_scores(self, im, g, x, rot):
        """Счёт каждого вида тайла для колонки набора, начинающейся в x: {код: счёт}; 'back' для рубашки."""
        if rot:
            y0, xt, banks, dx, dy = 644, x + 4, self.meld_cw + self.meld_ccw, 3, 3
            face = im[y0 + 4:y0 + 30, x + 10:x + 50]
        else:
            y0, xt, banks, dx, dy = 635, x + 6, self.meld_up, 3, 3
            face = im[y0 + 2:y0 + 28, x + 8:x + 40]
        f = face.astype(np.int16)
        if float(((f[..., 0] - f[..., 2] > 40) & (f[..., 0] > 110)).mean()) > 0.6:
            return {'back': 1.0}
        if blank(_gray(face)):
            return {'5z': 1.0}
        sc = {}
        for bk in banks:
            win = g[y0 - dy:y0 + bk.h + dy, xt - dx:xt + bk.w + dx]
            if win.shape[0] < bk.h + 2 * dy or win.shape[1] < bk.w + 2 * dx:
                continue
            m, _ = bk.match(win, dx, dy)
            for k, v in zip(bk.keys, m):
                if v > sc.get(k, -2):
                    sc[k] = float(v)
        return sc

    def melds(self, im):
        """Свои открытые наборы справа внизу: [(вид, [коды], откуда)]; [] если их нет; None если не удалось прочитать."""
        ext = self.meld_extent(im)
        if ext is None:
            return []
        L, R = ext
        key = ('melds', L, R, im[640:690:3, L:R:3].tobytes())
        if key in self.cache:
            return self.cache[key]
        g = _gray(im)
        UW, RW = self.MELD_UP_W, self.MELD_ROT_W
        memo = {}

        def S(x, rot):
            k = (x, rot)
            if k not in memo:
                memo[k] = self._meld_scores(im, g, x, rot)
            return memo[k]

        def get(sc, code):
            return sc.get(code, -1.0)
        kinds_all = [k for k in self.base if k != '5z'] + ['5z']
        SRCN = ['левый', 'напротив', 'правый']

        def hyp(x):
            """Все варианты набора, начинающегося в x: (ширина, счёт, набор)."""
            out = []
            # три колонки с одним повёрнутым (пон/чи/добавленный кан) и четыре (открытый кан)
            for ncol in (3, 4):
                for ri in range(ncol):
                    rots = [1 if i == ri else 0 for i in range(ncol)]
                    xs = []
                    xx = x
                    for r in rots:
                        xs.append(xx)
                        xx += RW if r else UW
                    width = xx - x
                    if abs(x + width - R) > 8 and x + width > R + 8:
                        continue
                    scs = [S(xx_, r) for xx_, r in zip(xs, rots)]
                    if any('back' in d for d in scs):
                        continue
                    # одинаковые тайлы
                    best_k, best_v = None, -9
                    for k in kinds_all:
                        v = sum(get(d, k) for d in scs) / ncol
                        if v > best_v:
                            best_k, best_v = k, v
                    if best_k is not None:
                        src = SRCN[0 if ri == 0 else (2 if ri == ncol - 1 else 1)]
                        if ncol == 4:
                            out.append((width, best_v, ('kan', [best_k] * 4, src)))
                        else:
                            xr, r_ = xs[ri], RW
                            top = im[606:640, xr + 8:xr + r_ - 8].astype(np.int16)
                            stacked = bool(top.size and (top.mean(2) > 140).mean() > 0.38)
                            out.append((width, best_v + (0.05 if stacked else 0), ('shouminkan', [best_k] * 4, src)) if stacked
                                       else (width, best_v, ('pon', [best_k] * 3, src)))
                    if ncol == 3:
                        # чи: три подряд идущих тайла одной масти, повёрнутый (взятый у левого) первым
                        if ri == 0:
                            for k0 in kinds_all:
                                if k0[1] not in 'mps' or int(k0[0]) > 7:
                                    continue
                                ks = [str(int(k0[0]) + j) + k0[1] for j in range(3)]
                                bv = -9
                                for perm in ((0, 1, 2), (0, 2, 1), (1, 0, 2), (1, 2, 0), (2, 0, 1), (2, 1, 0)):
                                    v = sum(get(scs[i], ks[perm[i]]) for i in range(3)) / 3
                                    if v > bv:
                                        bv, bperm = v, perm
                                codes = [ks[bperm[i]] for i in range(3)]
                                out.append((width, bv, ('chi', codes, 'левый')))
            # закрытый кан: рубашка, тайл, тайл, рубашка
            xs = [x + UW * i for i in range(4)]
            scs = [S(xx, 0) for xx in xs]
            if 'back' in scs[0] and 'back' in scs[3] and 'back' not in scs[1] and 'back' not in scs[2]:
                bk, bv = None, -9
                for k in kinds_all:
                    v = (get(scs[1], k) + get(scs[2], k)) / 2
                    if v > bv:
                        bk, bv = k, v
                out.append((UW * 4, bv, ('ankan', [bk] * 4, None)))
            return out

        best = {}

        def solve(x, left):
            if abs(x - R) <= 8:
                return (0.0, ())
            if left == 0 or x > R:
                return (-1e9, ())
            if (x, left) in best:
                return best[(x, left)]
            res = (-1e9, ())
            for width, v, m in hyp(x):
                nx = x + width
                v2, rest = solve(nx, left - 1)
                tot = v + v2
                if tot > res[0]:
                    res = (tot, (m,) + rest)
            best[(x, left)] = res
            return res
        tot, ms = solve(L, 4)
        out = list(ms) if ms and tot > -1e8 else None
        if out is not None and any(m[0] in ('chi', 'pon', 'kan', 'shouminkan', 'ankan') and len(m[1]) == 0 for m in out):
            out = None
        if out is not None:
            avg = tot / len(out)
            if avg < 0.35:
                out = None
        self.cache[key] = out
        return out

    @staticmethod
    def seat_round(im):
        """Твой ветер места (по тому, в каком углу красная метка дилера) и ветер раунда (Восток/Юг по ширине надписи)."""
        a = im.astype(int)
        b, g, r = a[..., 0], a[..., 1], a[..., 2]
        red = (r > 140) & (g < 90) & (b < 90)
        sc = {k: int(red[y0:y1, x0:x1].sum()) for k, (x0, x1, y0, y1) in SEAT_BOX.items()}
        k = max(sc, key=sc.get)
        seat = SEAT_FROM_DEALER[k] if sc[k] >= 60 else None
        t = ((g > 105) & (b > 105) & (g - r > 35))[260:282, 755:850]
        cols = np.where(t.any(0))[0]
        rnd = None
        if len(cols) > 10:
            width = cols[-1] - cols[0] + 1      # «East 1» около 49 пикселей, «South 1» заметно шире
            rnd = 'S' if width >= 56 else 'E'
        return seat, rnd

    # ------------------------------------------------------------ всё вместе
    def observe(self, im):
        g = _gray(im)
        wl = self.wall(im)
        if wl is None:
            return dict(ok=False, why='wall')
        L, rl = self.side(im, g, 'L')
        R, rr = self.side(im, g, 'R')
        return dict(ok=True, turn=self.turn(im)[0], dora=[t[0] for t in self.dora_read(im, g) if t], wall=wl,
                    counters={}, disc=dict(me=[t[0] for t in self.mine(im, g)], right=[t[0] for t in R],
                                           across=[t[0] for t in self.across(im, g)], left=[t[0] for t in L]),
                    riichi_idx=dict(left=rl, right=rr), melds=[], seat_round=self.seat_round(im), hand=[(t[0] if t else '?') for t in self.hand(im)])
