"""Опасность тайлов против одного игрока в риичи. Порт risk/base.rs из Akagi (без разбора «нет шансов» по стене)."""
import sys;pass
from risk_data import KINDS,RISK_RATE,DORA_MULTI
K={n:i for i,n in enumerate(KINDS)}
TILE_TYPE=[('NoSuji19','Suji19'),('NoSuji28','Suji28'),('NoSuji37','Suji37'),
 ('NoSuji46','HalfSuji46B','HalfSuji46A','DoubleSuji46'),('NoSuji5','HalfSuji5','HalfSuji5','DoubleSuji5'),
 ('NoSuji46','HalfSuji46A','HalfSuji46B','DoubleSuji46'),('NoSuji37','Suji37'),('NoSuji28','Suji28'),('NoSuji19','Suji19')]
HONOR=[['OtakazeLeft1','OtakazeLeft2','OtakazeLeft3','OtakazeLeft3'],['YakuHaiLeft1','YakuHaiLeft2','YakuHaiLeft3','YakuHaiLeft3']]
def dora_of(ind):
    s,r=divmod(ind,9) if ind<27 else (None,None)
    if ind<27:return s*9+(r+1)%9
    if ind<31:return 27+(ind-27+1)%4
    return 31+(ind-31+1)%3
def risk_tiles(turns,safe,left,dora_tiles,bakaze,jikaze):
    """safe: множество индексов 0..33; left: остаток каждого типа (4 − видимые); возвращает список из 34 чисел (% риска)"""
    t=min(max(turns,1),19)
    def rr(name):return RISK_RATE[t][K[name]]
    def dm(i,name):
        m=1.0
        for d in dora_tiles:
            if d==i:m*=DORA_MULTI[K[name]]
        return m
    low=[False]*27
    for i in range(27):low[i]=i in safe
    for s in range(3):
        b=9*s
        if left[b+1]==0:low[b]=True
        if left[b+2]==0:low[b]=low[b+1]=True
        if left[b+3]==0:low[b+1]=low[b+2]=True
        if left[b+5]==0:low[b+6]=low[b+7]=True
        if left[b+6]==0:low[b+7]=low[b+8]=True
        if left[b+7]==0:low[b+8]=True
    risk=[0.0]*34
    for s in range(3):
        for j in range(9):
            i=9*s+j
            if j<3:pat=1 if low[i+3] else 0
            elif j<6:
                lo=1 if low[i-3] else 0;hi=1 if low[i+3] else 0;pat=(lo<<1)|hi
            else:pat=1 if low[i-3] else 0
            k=TILE_TYPE[j][pat];risk[i]=rr(k)*dm(i,k)
            if j==0 and (i+3) in safe and left[i]==0:risk[i]=0
            if j==8 and (i-3) in safe and left[i]==0:risk[i]=0
        if left[9*s+4]==0:
            for jj in (2,6):risk[9*s+jj]=rr('Suji37')*dm(9*s+jj,'Suji37')
    for i in range(27,34):
        if left[i]==0:risk[i]=0;continue
        yaku=i in (bakaze,jikaze) or i>=31
        k=HONOR[1 if yaku else 0][min(left[i]-1,3)];risk[i]=rr(k)*dm(i,k)
    for i in safe:risk[i]=0.0
    return risk
