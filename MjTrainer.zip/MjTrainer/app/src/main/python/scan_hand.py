try:
    import cv2
except ImportError:   # Android: OpenCV нет, берём замену на NumPy
    import cv_np as cv2
import numpy as np, os
HERE=os.environ.get('MJ_DATA') or os.path.dirname(os.path.abspath(__file__))
W,H=45,68
TPL=dict(np.load(os.path.join(HERE,'templates.npz')))
def scan(im, y0=568, y1=658, x0=222, x1=1165, thr=0.66, mind=38):
    strip=im[y0:y1,x0:x1]
    best=None;idx=[]
    resp=[]
    for k,t in TPL.items():
        r=cv2.matchTemplate(strip,t,cv2.TM_CCOEFF_NORMED)   # (h-H+1, w-W+1)
        resp.append(r.max(0));idx.append(k)
    resp=np.array(resp)               # tiles x positions
    score=resp.max(0); which=resp.argmax(0)
    peaks=[]
    order=np.argsort(-score)
    taken=np.zeros(len(score),bool)
    for p in order:
        if score[p]<thr: break
        if taken[max(0,p-mind):p+mind].any(): continue
        taken[p]=True
        peaks.append((p+x0,idx[which[p]],float(score[p])))
    peaks.sort()
    return peaks
