"""Трекер событий раздачи: копит историю сбросов, звонков, риичи и считает безопасные тайлы."""
ORDER=['me','right','across','left']          # порядок ходов против часовой стрелки
class Tracker:
    def __init__(self):self.reset()
    def reset(self):
        self.board={s:[] for s in ORDER}       # что сейчас видно у каждого игрока
        self.events=[]                         # (seq, seat, tile)
        self.riichi={}                         # seat -> seq события, на котором объявлено
        self.called=[]                         # (seat, tile): тайл ушёл из сброса в мелд
        self.last_turn=None;self.round_key=None;self.dora=[];self.wall=None
    def _next_seat(self,seat):return ORDER[(ORDER.index(seat)+1)%4]
    def update(self,o):
        if not o['ok']:return []
        key=(tuple(o['dora'][:1]),o['counters'].get('honba'))
        new=[]
        # новая раздача: счётчик стены вырос или сбросы стали короче чем были без звонка
        if self.wall is not None and o['wall'] is not None and o['wall']>self.wall+3:self.reset()
        if o['wall'] is not None:self.wall=o['wall']
        self.dora=o['dora']
        if o['turn']:self.last_turn=o['turn']
        grown=[]
        for s in ORDER:
            old,cur=self.board[s],o['disc'][s]
            if len(cur)>=len(old) and cur[:len(old)]==old:
                for t in cur[len(old):]:grown.append((s,t))
                self.board[s]=cur
            elif len(cur)==len(old)-1:                      # тайл забрали в мелд
                for i in range(len(old)):
                    if old[:i]+old[i+1:]==cur:
                        self.called.append((s,old[i]));self.board[s]=cur;break
            # иначе шум распознавания: этот кадр для игрока пропускаем
        # порядок между игроками в одном кадре: по очереди, начиная после последнего ходившего
        if grown:
            start=self._next_seat(self.events[-1][1]) if self.events else 'me'
            k=0;seq_order=[]
            while grown and k<12:
                for i,(s,t) in enumerate(grown):
                    if s==start:seq_order.append(grown.pop(i));break
                start=self._next_seat(start);k+=1
            seq_order+=grown
            for s,t in seq_order:
                self.events.append((len(self.events),s,t));new.append(self.events[-1])
        # риичи: по повёрнутому тайлу (индекс в сбросе игрока)
        for s,idx in (o.get('riichi_idx') or {}).items():
            if idx is not None and s not in self.riichi:
                n=0
                for e in self.events:
                    if e[1]==s:
                        if n==idx:self.riichi[s]=e[0];break
                        n+=1
        return new
    def genbutsu(self,seat):
        """Безопасные против seat тайлы: его сбросы + всё, что сбросили другие после его риичи."""
        safe={t for e in self.events if e[1]==seat for t in [e[2]]}
        if seat in self.riichi:
            r=self.riichi[seat]
            safe|={e[2] for e in self.events if e[0]>r and e[1]!=seat}
        return safe
