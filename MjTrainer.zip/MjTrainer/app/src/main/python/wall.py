try:
    import cv2
except ImportError:   # Android: OpenCV нет, берём замену на NumPy
    import cv_np as cv2
import numpy as np,glob
LAB={'23.37.36':'68','23.37.47':'67','23.38.11':'57','23.38.38':'43','23.40.20':'60','23.41.32':'38','23.41.47':'29','23.42.09':'15','23.42.36':'00','23.57.59':'47','23.58.15':'44','23.58.44':'30','23.59.19':'13','00.00.36':'38','00.00.50':'35','00.01.12':'25','00.03.03':'22','00.03.34':'04'}
def teal(im):
    reg=im[318:338,668:722].astype(int);b,g,r=reg[...,0],reg[...,1],reg[...,2]
    return ((g>105)&(b>105)&(g-r>35))
def digits(im):
    m=teal(im)
    if m.sum()<60:return None
    cols=m.any(0);runs=[];s=None
    for i,v in enumerate(cols):
        if v and s is None:s=i
        if not v and s is not None:runs.append((s,i-1));s=None
    if s is not None:runs.append((s,len(cols)-1))
    runs=[r for r in runs if r[1]-r[0]>=1]
    if len(runs)<3:return None
    out=[]
    rows=np.where(m.any(1))[0]
    for a,b in runs[-2:]:
        sub=m[:,a:b+1].astype(np.uint8)*255
        ys=np.where(sub.any(1))[0];sub=sub[ys[0]:ys[-1]+1]
        out.append(cv2.resize(sub,(8,12),interpolation=cv2.INTER_AREA).astype(float)/255)
    return out
def build(skip=None):
    import os
    d=np.load(os.path.join(os.environ.get('MJ_DATA') or os.path.dirname(os.path.abspath(__file__)),'wall_templates.npz'))
    return {c:d[c] for c in d.files}
def read(im,T):
    d=digits(im)
    if d is None:return None
    s=''
    for dd in d:s+=min(T,key=lambda c:((T[c]-dd)**2).sum())
    return int(s)
if __name__=='__main__':
    ok=0
    for f in sorted(glob.glob('shots*/*.jpg')):
        k=f[-12:-4];im=cv2.imread(f)
        if k in LAB:
            T=build(skip=k);r=read(im,T);ok+=(r is not None and f'{r:02d}'==LAB[k]);print(k,LAB[k],r)
        else:print(k,'-',read(im,build()))
    print(ok,len(LAB))
