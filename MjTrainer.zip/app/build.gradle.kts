plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

val withOpenCv = (project.findProperty("withOpenCv") ?: "false") == "true"
val buildPythonPath = project.findProperty("buildPythonPath") as String?

android {
    namespace = "com.mj.trainer"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mj.trainer"
        minSdk = 24
        targetSdk = 29
        versionCode = 1
        versionName = "0.3"
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }   // Redmi 9C (32 бита) и Realme Narzo 50A (64 бита)
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

chaquopy {
    defaultConfig {
        version = "3.11"
        if (buildPythonPath != null) buildPython(buildPythonPath)
        pip {
            install("numpy")
            if (withOpenCv) install("opencv-python-headless")
        }
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
}
