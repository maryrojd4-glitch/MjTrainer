package com.mj.trainer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer

/**
 * Снимает экран, отдаёт кадр Python-движку и показывает совет в панели поверх игры.
 * Ничего никуда не отправляет и в игру ничего не нажимает.
 */
class CaptureService : Service() {
    companion object {
        const val MAX_DEBUG_FRAMES = 40
        const val MIN_CYCLE_MS = 600L
        fun logFile(c: Context): File = File(c.getExternalFilesDir(null), "trainer_log.jsonl")
        fun framesDir(c: Context): File = File(c.getExternalFilesDir(null), "frames").apply { mkdirs() }
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var w = 0
    private var h = 0
    private var dpi = 0
    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var worker: Handler? = null
    @Volatile private var alive = false
    private var panel: OverlayPanel? = null
    private var engine: PyObject? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ch = "mj_capture"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(ch, "Тренер", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, ch).setContentTitle("Тренер: читает экран").setSmallIcon(android.R.drawable.ic_menu_camera).build()
        if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(1, n)
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION") val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, main)
        panel = OverlayPanel(this)
        Shared.running = true
        Shared.status = "Запускаю…"
        alive = true
        thread = HandlerThread("mj-worker").also { it.start() }
        worker = Handler(thread!!.looper)
        worker?.post { loop() }
        return START_NOT_STICKY
    }

    private fun realSize(): Triple<Int, Int, Int> {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION") (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(m)
        return Triple(m.widthPixels, m.heightPixels, m.densityDpi)
    }

    private fun syncSize() {
        val (nw, nh, nd) = realSize()
        if (nw == w && nh == h && vd != null) return
        w = nw; h = nh; dpi = nd
        reader?.close()
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        if (vd == null) {
            vd = projection?.createVirtualDisplay("mj", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, main)
        } else {
            vd!!.resize(w, h, dpi); vd!!.surface = reader!!.surface
        }
    }

    private fun show(lines: List<String>) {
        val prefs = getSharedPreferences("mj", Context.MODE_PRIVATE)
        val corner = prefs.getString("corner", "bl") ?: "bl"
        main.post { try { panel?.show(lines, corner) } catch (e: Throwable) { android.util.Log.e("MJ", "overlay", e) } }
    }

    private fun loop() {
        val rawFile = File(cacheDir, "frame.raw")
        try {
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
            val dataDir = File(filesDir, "mj").apply { mkdirs() }
            for (name in assets.list("mj") ?: emptyArray()) {
                val dst = File(dataDir, name)
                if (!dst.exists() || dst.length() == 0L) {
                    assets.open("mj/$name").use { i -> FileOutputStream(dst).use { o -> i.copyTo(o) } }
                }
            }
            engine = Python.getInstance().getModule("engine").callAttr("Engine", dataDir.absolutePath, logFile(this).absolutePath)
        } catch (e: Throwable) {
            Shared.status = "Не удалось запустить Python: $e"
            show(listOf("Ошибка запуска", e.toString()))
            return
        }
        Shared.status = "Работает"
        show(listOf("Тренер запущен", "Открой игру горизонтально"))
        while (alive) {
            val t0 = System.currentTimeMillis()
            try {
                syncSize()
                val prefs = getSharedPreferences("mj", Context.MODE_PRIVATE)
                engine?.callAttr("set_options", prefs.getString("seat", "E"), prefs.getString("round", "E"), prefs.getBoolean("auto", true), prefs.getBoolean("replay", false))
                val img = reader?.acquireLatestImage()
                if (img != null) {
                    var wpad = img.width
                    try {
                        val p = img.planes[0]
                        wpad = p.rowStride / p.pixelStride
                        val buf = p.buffer
                        buf.rewind()
                        RandomAccessFile(rawFile, "rw").use { f -> f.channel.use { c -> c.position(0); while (buf.hasRemaining()) c.write(buf) } }
                    } finally { img.close() }
                    val js = JSONObject(engine!!.callAttr("frame_file", rawFile.absolutePath, w, h, wpad).toString())
                    val status = js.getString("status")
                    val arr = js.getJSONArray("lines")
                    val lines = ArrayList<String>()
                    for (i in 0 until arr.length()) lines.add(arr.getString(i))
                    Shared.full = js.getString("full")
                    Shared.status = "Работает (" + status + ", " + js.optInt("ms") + " мс)"
                    if (status == "advice" || status == "wait" || status == "error" || status == "nogame" || status == "rotate") show(lines)
                    if (js.optBoolean("save") && prefs.getBoolean("debug", false)) saveFrame(rawFile, wpad)
                }
            } catch (e: Throwable) {
                android.util.Log.e("MJ", "loop", e)
                Shared.status = "Ошибка: $e"
            }
            val dt = System.currentTimeMillis() - t0
            if (dt < MIN_CYCLE_MS) try { Thread.sleep(MIN_CYCLE_MS - dt) } catch (e: InterruptedException) { }
        }
    }

    private fun saveFrame(raw: File, wpad: Int) {
        try {
            val bytes = raw.readBytes()
            val bmp = Bitmap.createBitmap(wpad, h, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(ByteBuffer.wrap(bytes))
            val crop = Bitmap.createBitmap(bmp, 0, 0, w, h)
            val dir = framesDir(this)
            val f = File(dir, "advice_%d.png".format(System.currentTimeMillis()))
            FileOutputStream(f).use { crop.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val files = dir.listFiles()?.sortedBy { it.name } ?: emptyList()
            if (files.size > MAX_DEBUG_FRAMES) for (old in files.take(files.size - MAX_DEBUG_FRAMES)) old.delete()
        } catch (e: Throwable) { android.util.Log.e("MJ", "save", e) }
    }

    override fun onDestroy() {
        alive = false
        Shared.running = false
        Shared.status = "Остановлено"
        main.post { panel?.hide() }
        try { vd?.release(); reader?.close(); projection?.stop() } catch (e: Throwable) { }
        thread?.quitSafely()
        super.onDestroy()
    }
}
