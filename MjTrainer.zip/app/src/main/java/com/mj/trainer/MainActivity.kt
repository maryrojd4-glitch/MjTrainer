package com.mj.trainer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : AppCompatActivity() {
    private val REQ = 1001
    private lateinit var info: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("mj", Context.MODE_PRIVATE) }

    private val winds = listOf("E" to "Восток", "S" to "Юг", "W" to "Запад", "N" to "Север")
    private val corners = listOf("bl" to "слева внизу", "br" to "справа внизу", "tr" to "справа вверху", "tl" to "слева вверху")

    private fun spinner(title: String, items: List<Pair<String, String>>, key: String, def: String, parent: LinearLayout) {
        parent.addView(TextView(this).apply { text = title; setPadding(0, 16, 0, 0) })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items.map { it.second })
        val cur = prefs.getString(key, def) ?: def
        sp.setSelection(Math.max(0, items.indexOfFirst { it.first == cur }))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (key == "corner" && prefs.getString(key, def) != items[pos].first) prefs.edit().remove("px").remove("py").apply()
                prefs.edit().putString(key, items[pos].first).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) { }
        }
        parent.addView(sp)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        root.addView(TextView(this).apply { text = "Тренер по риичи для Mahjong Soul"; textSize = 20f })
        val auto = CheckBox(this).apply {
            text = "Определять ветер места и раунда автоматически (рекомендуется)"
            isChecked = prefs.getBoolean("auto", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("auto", c).apply() }
        }
        root.addView(auto)
        spinner("Запасной ветер места (если не удалось определить):", winds, "seat", "E", root)
        spinner("Запасной ветер раунда:", winds, "round", "E", root)
        spinner("Где показывать подсказку:", corners, "corner", "bl", root)
        val dbg = CheckBox(this).apply {
            text = "Сохранять кадры с советами (для разбора)"
            isChecked = prefs.getBoolean("debug", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("debug", c).apply() }
        }
        root.addView(dbg)
        val rep = CheckBox(this).apply {
            text = "Режим разбора партии (совет при любой руке из 14 тайлов, для сравнения с MAKA)"
            isChecked = prefs.getBoolean("replay", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("replay", c).apply() }
        }
        root.addView(rep)
        val reset = Button(this).apply { text = "Сбросить положение панели" }
        reset.setOnClickListener {
            prefs.edit().remove("px").remove("py").apply()
            Toast.makeText(this, "Панель вернётся в выбранный угол", Toast.LENGTH_SHORT).show()
        }
        root.addView(reset)
        val start = Button(this).apply { text = "Запустить тренер" }
        val stop = Button(this).apply { text = "Остановить" }
        val share = Button(this).apply { text = "Поделиться журналом и кадрами" }
        root.addView(start); root.addView(stop); root.addView(share)
        info = TextView(this).apply { textSize = 14f; setPadding(0, 16, 0, 0) }
        root.addView(info)
        setContentView(ScrollView(this).apply { addView(root) })

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Разреши показ поверх других приложений и нажми «Запустить» ещё раз", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), REQ)
            }
        }
        stop.setOnClickListener { stopService(Intent(this, CaptureService::class.java)) }
        share.setOnClickListener { shareLogs() }
        tick()
    }

    private fun tick() {
        val t = if (Shared.running) Shared.status + "\n\n" + Shared.full else "Тренер остановлен.\n\nЖурнал: " + CaptureService.logFile(this).absolutePath
        info.text = t
        ui.postDelayed({ tick() }, 1000)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data)
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this, "Запущено. Открой Mahjong Soul (горизонтально).", Toast.LENGTH_LONG).show()
            } else Toast.makeText(this, "Разрешение на захват экрана не выдано", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareLogs() {
        try {
            val dir = File(cacheDir, "share").apply { mkdirs() }
            val zip = File(dir, "mj_log.zip")
            ZipOutputStream(FileOutputStream(zip)).use { z ->
                val log = CaptureService.logFile(this)
                if (log.exists()) { z.putNextEntry(ZipEntry("trainer_log.jsonl")); z.write(log.readBytes()); z.closeEntry() }
                for (f in CaptureService.framesDir(this).listFiles() ?: emptyArray()) {
                    z.putNextEntry(ZipEntry("frames/" + f.name)); z.write(f.readBytes()); z.closeEntry()
                }
            }
            val uri = FileProvider.getUriForFile(this, "com.mj.trainer.files", zip)
            val i = Intent(Intent.ACTION_SEND).setType("application/zip").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Отправить журнал"))
        } catch (e: Throwable) {
            Toast.makeText(this, "Не получилось собрать архив: $e", Toast.LENGTH_LONG).show()
        }
    }
}
