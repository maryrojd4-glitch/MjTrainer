import sys,importlib.metadata as _m
_o=_m.version;_m.version=lambda n:'0.14.0' if n=='jansou' else _o(n)
import os
sys.path.insert(0,os.environ.get('MJ_JANSOU_SRC','jansou-main/src'))
from jansou.core.notation import parse_mpsz
from jansou.core.hand import Hand,Meld,MeldType,CallSource
from jansou.core.tiles import counts_by_kind,NUM_KINDS
from jansou.analysis.efficiency import discard_evaluation
SRC={'левый':CallSource.KAMICHA,'напротив':CallSource.TOIMEN,'правый':CallSource.SHIMOCHA}
def T(s):
    r=s[:-1].replace('r','')   # красная 5 помечена 'r' в конце номера, например '5mr'
    return parse_mpsz(r[0]+s[-1] if False else (s.replace('r','')[0]+s.replace('r','')[1]))[0]
def tile(code):
    c=code.replace('r','');return parse_mpsz(c[0]+c[1])[0]
def build_hand(concealed,melds):
    ms=[]
    for kind,tiles,src in melds:
        ts=tuple(tile(t) for t in tiles)
        mt={'chi':MeldType.CHII,'pon':MeldType.PON,'kan':MeldType.DAIMINKAN}[kind]
        ms.append(Meld(mt,ts,called=ts[0] if src else None,source=SRC.get(src)))
    return Hand(tuple(tile(t) for t in concealed),tuple(ms))
def visible_counts(hand_codes,melds,discards,dora):
    v=[0]*NUM_KINDS
    for t in hand_codes:v[tile(t).kind]+=1
    for _,ts,_s in melds:
        for t in ts:v[tile(t).kind]+=1
    for lst in discards.values():
        for t in lst:v[tile(t).kind]+=1
    for t in dora:v[tile(t).kind]+=1
    return v
def advise(concealed,melds,discards,dora,safe_sets):
    h=build_hand(concealed,melds)
    # visible считает тайлы вне руки; руку и свои мелды исключаем, т.к. jansou учитывает руку сам
    v=[0]*NUM_KINDS
    for lst in discards.values():
        for t in lst:v[tile(t).kind]+=1
    for _,ts,s in melds:
        for t in ts:v[tile(t).kind]+=1
    for t in dora:v[tile(t).kind]+=1
    opts=discard_evaluation(h,visible=v)
    out=[]
    for o in opts[:6]:
        name=str(o.discard) if not hasattr(o.discard,'name') else o.discard.name
        out.append((name,o.shanten,o.total_acceptance,{k.name if hasattr(k,'name') else str(k):n for k,n in o.acceptance.items()} if hasattr(o,'acceptance') else None))
    return opts,out

# ---------- слой стоимости и защиты ----------
from jansou.core.rules import Rules
from jansou.core.tiles import Wind,Tile,TileKind
from jansou.analysis.ev import discard_outlooks,Valuation
import risk as RK
NAMES={0:'m',9:'p',18:'s'}
def kname(k):
    k=int(k)
    if k<27:return f"{k%9+1}{'mps'[k//9]}"
    return ['Восток','Юг','Запад','Север','Белый дракон','Зелёный дракон','Красный дракон'][k-27]
def tile2(code):
    red=code.endswith('r');c=code.replace('r','')
    t=parse_mpsz(c[0]+c[1])[0]
    return Tile(t.kind,red=True) if red else t
def build_hand2(concealed,melds):
    ms=[]
    for kind,tiles,src in melds:
        ts=tuple(tile2(t) for t in tiles)
        mt={'chi':MeldType.CHII,'pon':MeldType.PON,'kan':MeldType.DAIMINKAN}[kind]
        ms.append(Meld(mt,ts,called=ts[0] if src else None,source=SRC.get(src)))
    return Hand(tuple(tile2(t) for t in concealed),tuple(ms)),tuple(ms)
def advise2(concealed,melds,obs,tracker,seat_wind=Wind.SOUTH,round_wind=Wind.EAST,horizon=8):
    hand,ms=build_hand2(concealed,melds)
    inds=tuple(tile2(t) for t in obs['dora'])
    vis=[0]*NUM_KINDS
    for lst in obs['disc'].values():
        for t in lst:vis[tile2(t).kind]+=1
    for _,ts,_s in melds:
        for t in ts:vis[tile2(t).kind]+=1
    for t in obs['dora']:vis[tile2(t).kind]+=1
    mine={}
    for _,ts,_s in melds:
        for t in ts:mine[tile2(t).kind]=mine.get(tile2(t).kind,0)+1
    for _seat,t in getattr(tracker,'called',[]):      # тайлы, забранные в мелды (кроме моих, они уже учтены)
        k=tile2(t).kind
        if mine.get(k,0)>0:mine[k]-=1
        else:vis[k]+=1
    reds=[0]*NUM_KINDS
    for t in concealed:
        if t.endswith('r'):reds[tile2(t).kind]+=1
    val=Valuation(rules=Rules(kuitan=True,aka_dora=True,nagashi_mangan=True,abort_kyuushu_kyuuhai=True,kuikae_ban=True),melds=ms,dora_indicators=inds,round_wind=round_wind,seat_wind=seat_wind,red_fives=tuple(reds) if any(reds) else ())
    opts=discard_evaluation(hand,visible=vis)
    counts=counts_by_kind(hand.concealed)
    outl=discard_outlooks(counts,len(ms),horizon,visible=vis,valuation=val)
    # опасность
    own=[0]*NUM_KINDS
    for t in concealed:own[tile2(t).kind]+=1
    left=[max(0,4-vis[i]-own[i]) for i in range(34)]
    dora_t=[RK.dora_of(int(tile2(t).kind)) for t in obs['dora']]
    names={'left':'слева','right':'справа','across':'напротив'}
    riichi=[s for s in tracker.riichi if s!='me']
    riskv={}
    for s in riichi:
        safe={int(tile2(t).kind) for t in tracker.genbutsu(s)}
        riskv[s]=RK.risk_tiles(len(obs['disc'][s]),safe,left,dora_t,27+int(round_wind),27+int(seat_wind))
    rows=[]
    for o in opts:
        k=int(o.discard);ol=outl.get(o.discard)
        rk=max([riskv[s][k] for s in riskv],default=0.0)
        rows.append(dict(tile=kname(k),shanten=o.shanten,ukeire=o.total_acceptance,
            win=(ol.win[-1] if ol else None),ready=(ol.ready[-1] if ol else None),points=(ol.points[-1] if ol and ol.points else None),
            risk=round(rk,1)))
    best_shanten=min(r['shanten'] for r in rows)
    attack=[r for r in rows if r['shanten']==best_shanten]
    attack.sort(key=lambda r:(-(r['win'] or 0)*(r['points'] or 1),-r['ukeire']))
    fold=sorted(rows,key=lambda r:(r['risk'],r['shanten'],-r['ukeire']))
    mode='attack'
    if riichi and best_shanten>=2:mode='fold'
    elif riichi and best_shanten==1 and (attack[0]['risk']>8 and (attack[0]['win'] or 0)<0.35):mode='fold'
    return dict(mode=mode,riichi=riichi,rows=rows,attack=attack[:3],fold=fold[:3],best_shanten=best_shanten)

def explain(r,horizon=8):
    """Текст подсказки на русском: рекомендация, 2 альтернативы и причина."""
    def line(x):
        s=f"сбросить {x['tile']}: {x['shanten']}-шант, принимает {x['ukeire']} тайлов"
        if x['win'] is not None:s+=f", шанс выиграть за {horizon} взятий {x['win']*100:.0f}%"
        if x['points']:s+=f", ~{x['points']:.0f} очков"
        if r['riichi']:s+=f", опасность {x['risk']:.1f}%"
        return s
    lst=r['fold'] if r['mode']=='fold' else r['attack']
    out=[]
    names={'left':'слева','right':'справа','across':'напротив'}
    if r['mode']=='fold':
        who=', '.join(names[s] for s in r['riichi'])
        out.append(f"ЗАЩИТА (риичи {who}): рука далеко от тенпая — безопаснее сбросить тайл с минимальным риском.")
    else:
        out.append("АТАКА: выбираем сброс с лучшим шантом, затем по шансу выигрыша и стоимости.")
    for i,x in enumerate(lst[:3]):out.append(('★ ' if i==0 else '  ')+line(x))
    return '\n'.join(out)

# ================= яку-осведомлённый выбор (advise3) =================
import dataclasses
from jansou.analysis.ev import hand_outlook
from jansou.analysis.shanten import shanten_counts
from jansou.scoring.score import score,ScoringError
from jansou.scoring.context import WinContext
from jansou.scoring.yaku import Yaku
YAKU_RU={'RIICHI':'риичи','MENZEN_TSUMO':'цумо закрытой рукой','PINFU':'пинфу','IIPEIKOU':'иипэйко','TANYAO':"тан'яо",
 'YAKUHAI_HAKU':'Якухай (белый дракон)','YAKUHAI_HATSU':'Якухай (зелёный дракон)','YAKUHAI_CHUN':'Якухай (красный дракон)',
 'YAKUHAI_ROUND':'Якухай (ветер раунда)','YAKUHAI_SEAT':'Якухай (ветер места)','CHIITOITSU':'тиитойцу','SANSHOKU_DOUJUN':'санщоку',
 'ITTSU':'иццу','CHANTA':'чанта','TOITOI':'тойтой','SANANKOU':'сананко','SANSHOKU_DOUKOU':'санщоку докоу','SANKANTSU':'санканцу',
 'SHOUSANGEN':'шосангэн','HONROUTOU':'хонроуто','HONITSU':'хоницу','JUNCHAN':'джунчан','RYANPEIKOU':'рянпэйко','CHINITSU':'чиницу',
 'HAITEI':'хайтэй','HOUTEI':'хотэй','RINSHAN':'ринсян'}
def yname(y):return YAKU_RU.get(y.name,y.name.lower())
def _kind_of(code):return int(tile2(code).kind)
def yaku_hints(concealed,melds,seat_wind,round_wind):
    """Какие яку у руки уже есть или достижимы (эвристика): список названий."""
    ck=[_kind_of(t) for t in concealed];mk=[[_kind_of(t) for t in ts] for _,ts,_s in melds]
    allk=ck+[k for m in mk for k in m]
    hints=[]
    yh={31:'Якухай (белый дракон)',32:'Якухай (зелёный дракон)',33:'Якухай (красный дракон)',27+int(round_wind):'Якухай (ветер раунда)',27+int(seat_wind):'Якухай (ветер места)'}
    for (kind,ts,_s),m in zip(melds,mk):
        if kind in('pon','kan') and m[0] in yh:hints.append(yh[m[0]]+' (мелд)')
    from collections import Counter
    c=Counter(ck)
    for k,n in c.items():
        if k in yh and n>=2:hints.append(yh[k]+(' (пара: можно собрать пон)' if n==2 else ' (сет)'))
    simple=lambda k:k<27 and k%9 not in(0,8)
    out_s=sum(1 for k in ck if not simple(k));melds_simple=all(all(simple(k) for k in m) for m in mk)
    if melds_simple and out_s<=3:hints.append(f"Таняо (лишних терминалов/чести в руке: {out_s})")
    suits=[k//9 for k in allk if k<27]
    if suits:
        top=max(set(suits),key=suits.count);other=sum(1 for k in allk if k<27 and k//9!=top)
        mel_ok=all(all((k<27 and k//9==top) or k>=27 for k in m) for m in mk)
        if mel_ok and other<=3:
            honors=sum(1 for k in allk if k>=27)
            hints.append(('Чиницу' if honors==0 else 'Хоницу')+f" (лишних тайлов других мастей: {other})")
    return hints
def tenpai_waits(after_codes,melds,vis,own_after,obs,seat_wind,round_wind,rules):
    """Для тенпая: ожидания и яку на каждом (рон). Возвращает [(тайл, осталось, названия яку или None)]."""
    from jansou.analysis.efficiency import acceptance
    res=[]
    h,ms=build_hand2(after_codes,melds)
    acc=acceptance(h,visible=vis)
    inds=tuple(tile2(t) for t in obs['dora'])
    ctx=WinContext(rules=rules,round_wind=round_wind,seat_wind=seat_wind,is_tsumo=False,dora_indicators=inds)
    for kind,n in acc.items():
        if n<=0:continue
        t=Tile(TileKind(int(kind)))
        full=Hand(tuple(tile2(x) for x in after_codes)+(t,),ms)
        try:
            r=score(full,t,ctx);res.append((kname(int(kind)),n,[yname(y.yaku) for y in r.yaku],r.han))
        except ScoringError:
            if not any(m[2] for m in melds):      # закрытая рука: яку появится после объявления риичи
                try:
                    rc=dataclasses.replace(ctx,riichi=True);r=score(full,t,rc)
                    res.append((kname(int(kind)),n,['только после риичи']+[yname(y.yaku) for y in r.yaku if y.yaku.name!='RIICHI'],r.han))
                    continue
                except ScoringError:pass
            res.append((kname(int(kind)),n,None,0))
    return res
def advise3(concealed,melds,obs,tracker,seat_wind=Wind.SOUTH,round_wind=Wind.EAST,horizon=8):
    base=advise2(concealed,melds,obs,tracker,seat_wind,round_wind,horizon)
    hand,ms=build_hand2(concealed,melds)
    inds=tuple(tile2(t) for t in obs['dora'])
    vis=[0]*NUM_KINDS
    for lst in obs['disc'].values():
        for t in lst:vis[tile2(t).kind]+=1
    for _,ts,_s in melds:
        for t in ts:vis[tile2(t).kind]+=1
    for t in obs['dora']:vis[tile2(t).kind]+=1
    reds0=[0]*NUM_KINDS
    for t in concealed:
        if t.endswith('r'):reds0[tile2(t).kind]+=1
    rules=Rules(kuitan=True,aka_dora=True,nagashi_mangan=True,abort_kyuushu_kyuuhai=True,kuikae_ban=True)
    counts=counts_by_kind(hand.concealed);nm=len(ms)
    best_sh=base['best_shanten']
    rows=[]
    byname={r['tile']:r for r in base['rows']}
    for code in sorted(set(c.replace('r','') for c in concealed),key=lambda c:(c[-1],c[0])):
        k=_kind_of(code)
        after=list(counts);after[k]-=1
        reds=list(reds0)
        for i in range(NUM_KINDS):
            if reds[i]>after[i]:reds[i]=after[i]
        val=Valuation(rules=rules,melds=ms,dora_indicators=inds,round_wind=round_wind,seat_wind=seat_wind,red_fives=tuple(reds) if any(reds) else ())
        sh=shanten_counts(after,nm)
        if sh>best_sh+1:continue
        ol=None;win=0.0;pts=0.0;deferred=(sh>best_sh)
        if not deferred:
            try:ol=hand_outlook(after,nm,horizon,visible=vis,valuation=val,max_distance=min(3,sh))
            except Exception:ol=None
            win=ol.win[-1] if ol else 0.0;pts=ol.points[-1] if ol and ol.points else 0.0
        # коды руки без одного тайла этого вида (красную оставляем, если можно)
        rest=list(concealed)
        pick=next((c for c in rest if c.replace('r','')==code and not c.endswith('r')),None) or next(c for c in rest if c.replace('r','')==code)
        rest.remove(pick)
        row=dict(tile=kname(k),code=code,shanten=sh,win=win,points=pts,ev=win*pts,deferred=deferred,_after=after,_val=val,
                 risk=byname.get(kname(k),{}).get('risk',0.0),ukeire=byname.get(kname(k),{}).get('ukeire',0))
        row['hints']=yaku_hints(rest,melds,seat_wind,round_wind)
        if sh==0:
            try:row['waits']=tenpai_waits(rest,melds,vis,None,obs,seat_wind,round_wind,rules)
            except Exception as e:row['waits']=None
        rows.append(row)
    open_hand=any(m[2] for m in melds)
    if open_hand and max((r['ev'] for r in rows if not r['deferred']),default=0)==0:
        for r in rows:           # все лучшие по шанту сбросы без выигрыша: смотрим и сбросы с шантом на 1 больше
            if r['deferred']:
                try:
                    ol=hand_outlook(r['_after'],nm,horizon,visible=vis,valuation=r['_val'],max_distance=min(3,r['shanten']))
                    r['win']=ol.win[-1];r['points']=ol.points[-1] if ol.points else 0.0;r['ev']=r['win']*r['points']
                except Exception:pass
    for r in rows:
        r.pop('_after',None);r.pop('_val',None)
    for r in rows:
        r['no_yaku']=bool(open_hand and not r['hints'] and r['points']==0)
    base['rows3']=rows
    base['open_hand']=open_hand
    rows_ok=[r for r in rows if r['shanten']<=best_sh+1]
    base['attack3']=sorted(rows_ok,key=lambda r:(-r['ev'],r['shanten'],-r['ukeire']))
    return base
def explain3(r,horizon=8):
    names={'left':'слева','right':'справа','across':'напротив'}
    out=[]
    if r['mode']=='fold':
        out.append("ЗАЩИТА (риичи "+', '.join(names[s] for s in r['riichi'])+"): рука далеко от тенпая или опасна — безопаснее сбросить тайл с минимальным риском.")
        lst=r['fold'];
    else:
        out.append("АТАКА: сброс выбирается по ожидаемой выгоде — шанс выиграть × стоимость с учётом яку.")
        lst=r['attack3'][:3]
    rows3={x['tile']:x for x in r['rows3']}
    for i,x in enumerate(lst[:3]):
        y=rows3.get(x['tile'],x)
        s=('★ ' if i==0 else '  ')+f"сбросить {x['tile']}: {y['shanten']}-шант"
        if r['mode']!='fold' or y.get('win'):
            if y['points']:s+=f", шанс выиграть за {horizon} взятий {y['win']*100:.0f}%, ~{y['points']:.0f} очков"
            elif r['open_hand']:s+=", выиграть нельзя: нет яку"
        if r['riichi']:s+=f", опасность {x['risk']:.1f}%"
        out.append(s)
        if y.get('waits'):
            w=[f"{t}×{n}: "+(', '.join(ys)+f" ({han} хан)" if ys else 'нет яку (кроме ситуационных: ринсян, хайтэй/хотэй, чанкан)') for t,n,ys,han in y['waits']]
            out.append('    ждёт: '+'; '.join(w))
        elif y['hints']:out.append('    яку: '+', '.join(y['hints']))
        elif r['open_hand']:out.append('    ⚠ открытая рука без яку — выиграть можно только набрав яку')
    if r['open_hand'] and r['mode']!='fold':
        top=r['attack3'][0] if r['attack3'] else None
        if top and top['points']==0:out.append('⚠ ВНИМАНИЕ: ни один сброс не даёт выигрыша — у руки нет яку. Нужно набирать яку (якухай, тан\'яо, хоницу…).')
    return '\n'.join(out)

def _yao(code):
    k=_kind_of(code);return k>=27 or k%9 in(0,8)
def nagashi_status(tracker,min_discards=4):
    """Нагаси-манган: все сбросы игрока — терминалы/чести и ни один не забран соперником (платится при ничьей стеной)."""
    res={}
    for s in ('me','right','across','left'):
        ts=[e[2] for e in tracker.events if e[1]==s]
        if len(ts)>=min_discards:
            res[s]=all(_yao(t) for t in ts) and not any(cs==s for cs,_ in tracker.called)
    return res
_orig_explain3=explain3
def explain3(r,horizon=8,tracker=None):
    t=_orig_explain3(r,horizon)
    if tracker is not None:
        names={'me':'у тебя','left':'у игрока слева','right':'у игрока справа','across':'у игрока напротив'}
        for s,ok in nagashi_status(tracker).items():
            if ok and s=='me':t+="\nℹ У тебя пока возможен нагаси-манган: все сбросы — терминалы/чести и ни один не забран. Платится, если раздача закончится ничьей по стене."
            elif ok:t+=f"\nℹ {names[s].capitalize()} возможен нагаси-манган (все сбросы — терминалы/чести, ни один не забран). Забрав любой его сброс (чи/пон), ты его сломаешь."
    return t

def summary(r):
    """Короткая сводка для журнала: режим, топ-3 с метриками и кодами тайлов."""
    rows3={x['tile']:x for x in r['rows3']}
    lst=r['fold'] if r['mode']=='fold' else r['attack3']
    top=[]
    for x in lst[:3]:
        y=rows3.get(x['tile'],x)
        top.append(dict(code=y.get('code'),tile=x['tile'],shanten=y['shanten'],ukeire=y.get('ukeire'),win=round(y.get('win') or 0,4),
                        points=round(y.get('points') or 0),risk=x.get('risk'),hints=y.get('hints')))
    return dict(mode=r['mode'],riichi=r['riichi'],best_shanten=r['best_shanten'],top=top)
_prev_explain3=explain3
def explain3(r,horizon=8,tracker=None):
    t=_prev_explain3(r,horizon,tracker)
    if r['mode']!='fold' and len(r['attack3'])>=2:
        a,b=r['attack3'][0],r['attack3'][1]
        if a['shanten']==b['shanten'] and abs(a['ev']-b['ev'])<=0.05*max(a['ev'],1) and abs(a['ukeire']-b['ukeire'])<=1:
            t+="\nℹ Первые два варианта практически равны по выгоде — разница в пределах погрешности расчёта, решай по стилю и ситуации."
    return t

# ================= версия 4: названия по правилам сообщества, горизонт по стене, список принимаемых тайлов, причины =================
YAKU_RU.update({
 'RIICHI':'Риичи','DOUBLE_RIICHI':'Дабл-риичи','IPPATSU':'Иппацу','MENZEN_TSUMO':'Мензен цумо','PINFU':'Пинфу','IIPEIKOU':'Иипейко',
 'TANYAO':'Таняо','SANSHOKU_DOUJUN':'Саншоку додзюн','ITTSU':'Иццу','YAKUHAI_HAKU':'Якухай (белый дракон)','YAKUHAI_HATSU':'Якухай (зелёный дракон)',
 'YAKUHAI_CHUN':'Якухай (красный дракон)','YAKUHAI_ROUND':'Якухай (ветер раунда)','YAKUHAI_SEAT':'Якухай (ветер места)','CHANTA':'Чанта',
 'RINSHAN':'Ринсян кайхо','CHANKAN':'Чанкан','HAITEI':'Хайтей','HOUTEI':'Хотей','CHIITOITSU':'Чиитойцу','SANSHOKU_DOUKOU':'Саншоку доко',
 'SANANKOU':'Сананко','SANKANTSU':'Санканцу','TOITOI':'Тойтой','HONITSU':'Хоницу','SHOUSANGEN':'Шосанген','HONROUTOU':'Хонрото',
 'JUNCHAN':'Джунчан','RYANPEIKOU':'Рянпейко','CHINITSU':'Чиницу','KOKUSHI':'Кокуши мусо','CHUUREN':'Чууренпото','TENHOU':'Тенхо','CHIIHOU':'Чихо',
 'SUUANKOU':'Сууанко','SUUKANTSU':'Сууканцу','RYUUIISOU':'Рюисо','CHINROUTOU':'Чинрото','TSUUIISOU':'Цуисо','DAISANGEN':'Дайсанген',
 'SHOUSUUSHI':'Шосуши','DAISUUSHI':'Дайсуши'})
_adv3=advise3
def advise4(concealed,melds,obs,tracker,seat_wind=Wind.SOUTH,round_wind=Wind.EAST,horizon=None):
    wall=obs.get('wall')
    left_draws=(wall//4) if isinstance(wall,int) else None
    if horizon is None:horizon=8 if left_draws is None else max(1,min(8,left_draws))
    r=_adv3(concealed,melds,obs,tracker,seat_wind,round_wind,horizon)
    r['horizon']=horizon;r['draws_left']=left_draws
    hand,ms=build_hand2(concealed,melds)
    vis=[0]*NUM_KINDS
    for lst in obs['disc'].values():
        for t in lst:vis[tile2(t).kind]+=1
    for _,ts,_s in melds:
        for t in ts:vis[tile2(t).kind]+=1
    for t in obs['dora']:vis[tile2(t).kind]+=1
    opts={int(o.discard):o for o in discard_evaluation(hand,visible=vis)}
    counts=counts_by_kind(hand.concealed)
    for row in r['rows3']:
        k=_kind_of(row['code']);o=opts.get(k)
        acc=sorted(((int(kk),n) for kk,n in (o.acceptance.items() if o else []) if n>0),key=lambda x:-x[1])
        row['acc']=[(kname(kk),n) for kk,n in acc]
        c=counts[k]
        if k>=27:linked=False
        else:
            linked=any(0<=k%9+d<=8 and counts[k+d]>0 for d in (-2,-1,1,2))
        row['role']=('часть пары' if c==2 else 'часть сета' if c>=3 else 'ни с чем не связан' if not linked else 'в связке с соседними тайлами')
    return r
def _pl(n,a,b,c):
    n=abs(int(n));return a if n%10==1 and n%100!=11 else b if 2<=n%10<=4 and not 12<=n%100<=14 else c
def _why(a,b,r,mode):
    out=[]
    if mode=='fold':
        if a['risk']==0 and b['risk']>0:out.append(f"{a['tile']} безопасен, у {b['tile']} опасность {b['risk']:.1f}%")
        elif a['risk']<b['risk']:out.append(f"опасность ниже: {a['risk']:.1f}% против {b['risk']:.1f}%")
        if a['shanten']>b['shanten']:out.append(f"ценой отдаления от тенпая ({a['shanten']}-шант вместо {b['shanten']}-шанта)")
        if not out:out.append("оба безопасны против всех риичи; "+(f"{a['tile']} лучше сохраняет руку" if a['ukeire']>b['ukeire'] else "для руки они равноценны"))
        return out
    if a['shanten']<b['shanten']:out.append(f"сохраняет {a['shanten']}-шант, а {b['tile']} отодвигает руку до {b['shanten']}-шанта")
    elif a['ukeire']>b['ukeire']:d=a['ukeire']-b['ukeire'];out.append(f"принимает на {d} {_pl(d,'тайл','тайла','тайлов')} больше ({a['ukeire']} против {b['ukeire']})")
    if b['points']==0 and b['win']>0 and r['open_hand']:out.append(f"после сброса {b['tile']} у открытой руки нет яку")
    elif a['points']>b['points']*1.1:
        extra=[h for h in a['hints'] if h not in b['hints']]
        out.append(f"рука дороже: ~{a['points']:.0f} против ~{b['points']:.0f} очков"+(f" ({'; '.join(extra)})" if extra else ''))
    if a['win']>b['win']*1.1 and a['points']>0:out.append(f"шанс собрать руку выше: {a['win']*100:.0f}% против {b['win']*100:.0f}%")
    if not out:out.append("варианты близки по всем показателям")
    return out
def explain4(r,tracker=None):
    names={'left':'слева','right':'справа','across':'напротив'}
    h=r['horizon'];dl=r['draws_left']
    if dl is None:horizon_txt=f"за ближайшие {h} твоих взятий"
    elif dl==1:horizon_txt="за последнее взятие из стены"
    elif h>=dl:horizon_txt=f"за оставшиеся ~{dl} твоих взятий из стены"
    else:horizon_txt=f"за ближайшие {h} твоих взятий (до конца раздачи их примерно {dl})"
    out=[f"Шанс выиграть считается {horizon_txt}."]
    if r['mode']=='fold':
        out.append("ЗАЩИТА (риичи "+', '.join(names[s] for s in r['riichi'])+"): рука далеко от тенпая или рискует — сбрасываем самое безопасное.")
        lst=r['fold']
    else:
        out.append("АТАКА: сброс выбран по ожидаемой выгоде (шанс выиграть × стоимость с учётом яку).")
        lst=r['attack3']
    rows3={x['tile']:x for x in r['rows3']}
    for i,x in enumerate(lst[:3]):
        y=rows3.get(x['tile'],x)
        s=('★ ' if i==0 else '  ')+f"сбросить {x['tile']} ({y['role']}): {y['shanten']}-шант"
        if y['acc']:
            s+="; принимает "+', '.join(f"{t}×{n}" for t,n in y['acc'][:8])+f" (всего {y['ukeire']})"
        if r['mode']!='fold' or y.get('win'):
            if y['points']:s+=f"; шанс выиграть {y['win']*100:.0f}%, ~{y['points']:.0f} очков"
            elif y['win']>0 and r['open_hand']:s+="; выиграть нельзя: нет яку"
            elif y['win']==0 and y['shanten']>0:s+="; до конца раздачи рука не успеет дойти до выигрыша"
        if r['riichi']:s+=f"; опасность {x['risk']:.1f}%"
        out.append(s)
        if y.get('waits'):
            w=[f"{t}×{n}: "+(', '.join(ys)+f" ({han} хан)" if ys else 'нет яку (кроме ситуационных: ринсян кайхо, хайтей, хотей, чанкан)') for t,n,ys,han in y['waits']]
            out.append('    ждёт: '+'; '.join(w))
        elif y['hints']:out.append('    яку: '+', '.join(y['hints']))
        elif r['open_hand'] and y['win']>0 and y['points']==0:out.append('    ⚠ открытая рука без яку — выиграть можно только набрав яку')
    if len(lst)>=2:
        out.append('Почему '+lst[0]['tile']+': '+'; '.join(_why(rows3.get(lst[0]['tile'],lst[0]),rows3.get(lst[1]['tile'],lst[1]),r,r['mode']))+'.')
    if r['open_hand'] and r['mode']!='fold':
        top=r['attack3'][0] if r['attack3'] else None
        if top and top['points']==0 and top['win']>0:out.append('⚠ ВНИМАНИЕ: ни один сброс не даёт выигрыша — у руки нет яку. Нужно набирать яку.')
        elif top and top['win']==0 and r['best_shanten']>=1 and dl is not None and dl<=2:out.append('ℹ В стене почти не осталось тайлов: рука не успеет дойти до выигрыша. Думай о защите и о тенпае к концу раздачи (выплаты за тенпай).')
    if r['mode']!='fold' and len(r['attack3'])>=2:
        a,b=r['attack3'][0],r['attack3'][1]
        if a['shanten']==b['shanten'] and abs(a['ev']-b['ev'])<=0.05*max(a['ev'],1) and abs(a['ukeire']-b['ukeire'])<=1:
            out.append("ℹ Первые два варианта практически равны — разница в пределах погрешности расчёта, решай по стилю и ситуации.")
    if tracker is not None:
        nm={'me':'у тебя','left':'у игрока слева','right':'у игрока справа','across':'у игрока напротив'}
        for s,ok in nagashi_status(tracker).items():
            if ok and s=='me':out.append("ℹ У тебя пока возможен нагаси манган: все сбросы — терминалы и благородные тайлы, ни один не взят. (В правилах сообщества по умолчанию его нет; выплачивается только если это включено.)")
            elif ok:out.append(f"ℹ {nm[s].capitalize()} возможен нагаси манган. Взяв любой его сброс в сет, ты его сломаешь.")
    return '\n'.join(out)
