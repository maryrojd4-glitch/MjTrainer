"""Движок тренера для Android: кадр экрана -> советы. Только читает пиксели, ничего не нажимает."""
import json
import os
import time
import traceback

import numpy as np

FW, FH = 1600, 720


class Engine:
    def __init__(self, data_dir, log_path):
        os.environ['MJ_DATA'] = data_dir
        self.log_path = log_path
        import phone
        import tracker
        import advisor
        from jansou.core.tiles import Wind
        self.phone, self.tracker_mod, self.advisor = phone, tracker, advisor
        self.WIND = {'E': Wind.EAST, 'S': Wind.SOUTH, 'W': Wind.WEST, 'N': Wind.NORTH}
        self.O = phone.Observer()
        self.T = tracker.Tracker()
        self.seat, self.rnd = 'E', 'E'
        self.key = None
        self.last = None          # последний показанный совет (dict)
        self.pending = None
        self.frames = 0

    def set_options(self, seat, rnd):
        if seat != self.seat or rnd != self.rnd:
            self.key = None
        self.seat, self.rnd = seat, rnd

    def _log(self, rec):
        try:
            with open(self.log_path, 'a', encoding='utf-8') as f:
                f.write(json.dumps(rec, ensure_ascii=False) + '\n')
        except Exception:
            pass

    @staticmethod
    def _to_bgr(arr, w, h):
        im = np.ascontiguousarray(arr[..., 2::-1])
        if (w, h) != (FW, FH):
            import cv_np
            im = cv_np.resize(im, (FW, FH))
        return im

    def frame_file(self, path, w, h, wpad):
        """Кадр лежит в файле: RGBA, строки по wpad пикселей (может быть шире w из-за выравнивания)."""
        try:
            arr = np.fromfile(path, np.uint8, count=wpad * h * 4).reshape(h, wpad, 4)[:, :w, :]
            return self._frame_arr(arr, w, h)
        except Exception:
            return self._out('error', ['Ошибка чтения кадра: ' + traceback.format_exc()[-300:]], traceback.format_exc(), False)

    def frame(self, rgba, w, h):
        return self._frame_arr(np.frombuffer(rgba, np.uint8).reshape(h, w, 4), w, h)

    def _frame_arr(self, arr, w, h):
        """Возвращает JSON-строку: status, lines (для панели), full (подробно), save (сохранить кадр)."""
        t0 = time.time()
        try:
            if w < h:
                return self._out('rotate', ['Поверни телефон: игра должна быть горизонтально'], '', False)
            im = self._to_bgr(arr, w, h)
            self.frames += 1
            o = self.O.observe(im)
            if not o['ok']:
                return self._out('nogame', ['Стол не виден (меню, оверлей или другой экран)'], '', False)
            new = self.T.update(o)
            for e in new:
                if e[1] == 'me' and self.pending:
                    p = self.pending
                    p['actual'] = e[2]
                    top = p['advice']['top']
                    p['matched_top1'] = bool(top and top[0]['code'] == e[2].replace('r', ''))
                    self._log(p)
                    self.pending = None
            adv = self.advisor
            n = len(o['hand'])
            dora = ' '.join(adv.kname(int(adv.tile2(t).kind)) for t in o['dora'])
            head = 'Стена %s, дора-индикатор: %s, ходит: %s' % (o['wall'], dora or '?', o['turn'] or '?')
            if self.T.riichi:
                names = {'left': 'слева', 'right': 'справа', 'across': 'напротив', 'me': 'ты'}
                head += '\nриичи: ' + ', '.join(names.get(s, s) for s in self.T.riichi)
            if o['turn'] == 'me' and n == 14:
                key = (tuple(o['hand']), tuple(self.T.riichi), len(self.T.events), tuple(o['dora']), self.seat, self.rnd)
                if key != self.key:
                    r = adv.advise4(o['hand'], [], o, self.T, seat_wind=self.WIND[self.seat], round_wind=self.WIND[self.rnd])
                    full = head + '\n\n' + adv.explain4(r, self.T)
                    lines = self._panel(r, adv.explain4(r, self.T))
                    self.key = key
                    self.last = dict(lines=lines, full=full)
                    self.pending = dict(t=time.strftime('%H:%M:%S'), hand=o['hand'], dora=o['dora'], wall=o['wall'],
                                        riichi=list(self.T.riichi), disc=o['disc'], advice=adv.summary(r),
                                        seat=self.seat, round=self.rnd)
                    return self._out('advice', lines, full, True, ms=(time.time() - t0) * 1000)
                if self.last:
                    return self._out('advice', self.last['lines'], self.last['full'], False)
            if o['turn'] == 'me' and n != 14:
                return self._out('wait', ['Вижу в руке %d тайлов. Открытые наборы пока не читаю — совета нет.' % n], head, False)
            return self._out('wait', ['Жду твоего хода…'], head, False)
        except Exception:
            return self._out('error', ['Ошибка: ' + traceback.format_exc()[-300:]], traceback.format_exc(), False)

    @staticmethod
    def _out(status, lines, full, save, ms=0):
        return json.dumps(dict(status=status, lines=lines, full=full, save=save, ms=round(ms)), ensure_ascii=False)

    @staticmethod
    def _panel(r, explain):
        """Короткий текст для панели поверх игры."""
        lst = r['fold'] if r['mode'] == 'fold' else r['attack3']
        rows3 = {x['tile']: x for x in r['rows3']}
        out = []
        if not lst:
            return ['Нет вариантов']
        a = lst[0]
        y = rows3.get(a['tile'], a)

        def sh(v):
            return 'тенпай' if v == 0 else ('готова' if v < 0 else '%d-шант' % v)
        out.append(('ЗАЩИТА: сбросить ' if r['mode'] == 'fold' else 'Сбросить ') + str(a['tile']))
        info = sh(y['shanten'])
        if r['mode'] == 'fold':
            info += ', опасность %.1f%%' % a.get('risk', 0)
        else:
            info += ', принимает %s' % y.get('ukeire')
            if y.get('points'):
                info += ', шанс %.0f%%' % (y['win'] * 100)
        out.append(info)
        alts = [str(x['tile']) for x in lst[1:3]]
        if alts:
            out.append('Также: ' + ', '.join(alts))
        for line in explain.split('\n'):
            if line.startswith('Почему'):
                out.append(line)
                break
        return out
