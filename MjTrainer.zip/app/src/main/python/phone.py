"""Чтение стола Mahjong Soul на телефоне (кадр 1600x720, альбомная ориентация).
Всё построено на NumPy: окна сравниваются с шаблонами одним матричным умножением."""
import os
import numpy as np
try:
    import cv2
except ImportError:
    import cv_np as cv2
import scan_hand

HERE = os.path.dirname(os.path.abspath(__file__))
FW, FH = 1600, 720

# ---------------------------------------------------------------- шаблоны
def _gray(a):
    a = a.astype(np.float32)
    return 0.114 * a[..., 0] + 0.587 * a[..., 1] + 0.299 * a[..., 2]


class Bank:
    """Набор шаблонов одного размера (серые, с вычтенным средним и единичной нормой)."""
    def __init__(self, items, w, h):
        self.w, self.h = w, h
        self.keys, rows = [], []
        for key, img in items:
            g = _gray(img)
            g = g - g.mean()
            n = np.sqrt((g * g).sum())
            if n < 1e-3:
                continue
            self.keys.append(key)
            rows.append((g / n).ravel())
        self.M = np.array(rows, np.float32)

    def match(self, gray_patch, dx, dy):
        """gray_patch: окно размера (h+2*dy, w+2*dx). Возвращает лучший счёт по каждому шаблону."""
        h, w = self.h, self.w
        sh = np.lib.stride_tricks.sliding_window_view(gray_patch, (h, w))   # (2dy+1, 2dx+1, h, w)
        W = sh.reshape(-1, h * w).astype(np.float32)
        W = W - W.mean(1, keepdims=True)
        n = np.sqrt((W * W).sum(1, keepdims=True))
        W = W / np.maximum(n, 1e-3)
        S = self.M @ W.T                                   # (шаблонов, сдвигов)
        return S.max(1), S.argmax(1)


def _variants(base_imgs, sizes, rot=None, crops=((0, None),)):
    """base_imgs: {код: картинка тайла 45x68}. Возвращает {размер: [(код, картинка)]}"""
    out = {s: [] for s in sizes}
    for k, t in base_imgs.items():
        for a, b in crops:
            c = t[a:b]
            if rot is not None:
                c = cv2.rotate(c, rot)
            for s in sizes:
                out[s].append((k, cv2.resize(c, s, interpolation=cv2.INTER_AREA)))
    return out


def best_of(banks, gray_win, dx, dy, topn=2):
    """Лучший код среди всех банков (разные размеры шаблонов)."""
    sc = {}
    for b in banks:
        if gray_win.shape[0] < b.h or gray_win.shape[1] < b.w:
            continue
        s, _ = b.match(gray_win[: b.h + 2 * dy, : b.w + 2 * dx], dx, dy)
        for k, v in zip(b.keys, s):
            if v > sc.get(k, -2):
                sc[k] = float(v)
    top = sorted(sc.items(), key=lambda kv: -kv[1])[:topn]
    return top


def red_fraction(c):
    c = c.astype(int)
    b, g, r = c[..., 0], c[..., 1], c[..., 2]
    return float(((r > 120) & (r - g > 55) & (r - b > 55)).mean())


def blank(face_gray):
    return face_gray.mean() > 150 and float((face_gray < 150).mean()) < 0.10


def tile_present(face):
    f = face.astype(int)
    b, g, r = f[..., 0], f[..., 1], f[..., 2]
    return (((abs(r - b) < 28) & (abs(g - b) < 28)).mean() > 0.33) or ((((r + g + b) / 3) > 170).mean() > 0.30)


# ---------------------------------------------------------------- геометрия (подогнана по кадрам)
# свои сбросы: три ряда слева направо
OWN_ROWS = [(673.0, 41.5, 362), (670.0, 42.1, 404), (666.0, 42.8, 447)]
OWN_W, OWN_H = 39, 38
# напротив: ряды от ближнего, справа налево; тайлы перевёрнуты на 180°
ACR_ROWS = [(872.0, 36.4, 162, 32), (872.0, 35.4, 132, 30), (872.0, 34.5, 102, 28), (872.0, 33.8, 74, 26)]
ACR_W = 36
# левый игрок: колонка 0 ближе к центру, колонки идут влево; в колонке сверху вниз; тайл повёрнут на 90° по часовой
LEFT_Y0, LEFT_DY = 194.0, 25.6
# правый игрок: колонка 0 ближе к центру, колонки идут вправо; в колонке снизу вверх
RIGHT_Y0, RIGHT_DY = 195.5, 25.9
SIDE_W, SIDE_H = 47, 24


def left_xy(c, r):
    return 627.5 - 2.6 * r - c * (46.5 + 1.1 * r), LEFT_Y0 + LEFT_DY * r


def right_xy(c, r):
    return 919.0 + 2.0 * r + c * (50.0 + 1.2 * r), RIGHT_Y0 + RIGHT_DY * r


# рука
HAND_X0, HAND_PITCH, HAND_Y = 308.0, 63.2, 614
HAND_W, HAND_H = 62, 94
# дора
DORA_X0, DORA_PITCH, DORA_Y, DORA_W, DORA_H = 46.0, 37.5, 31, 35, 51
# счётчик стены (бирюзовые цифры «×61»)
WALL_BOX = (772, 835, 284, 306)
TURN_BOX = {'me': (765, 835, 330, 344), 'across': (765, 835, 214, 232),
            'left': (706, 730, 260, 306), 'right': (868, 892, 256, 304)}


SEAT_BOX = {'me': (690, 728, 330, 356), 'right': (872, 910, 328, 356), 'across': (866, 904, 212, 236), 'left': (700, 740, 212, 236)}
# ветер игрока с красной меткой «Е» (дилер) -> твой ветер: me=E, right(дилер справа)=N, across=W, left=S
SEAT_FROM_DEALER = {'me': 'E', 'right': 'N', 'across': 'W', 'left': 'S'}


class Observer:
    def __init__(self):
        base = dict(scan_hand.TPL)
        self.base = base
        blank_key = '5z'
        self.hand_bank = Bank(self._hand_items(base), 31, 47)
        s_own = [(OWN_W - 1, OWN_H - 1), (OWN_W, OWN_H), (OWN_W + 1, OWN_H + 1)]
        v = _variants(base, s_own, crops=((4, 58),))
        self.own = [Bank(v[s], s[0], s[1]) for s in s_own]
        s_acr = [(ACR_W - 1, 29), (ACR_W, 31), (ACR_W, 33)]
        v = _variants(base, s_acr, rot=cv2.ROTATE_180, crops=((4, 58),))
        self.acr = [Bank(v[s], s[0], s[1]) for s in s_acr]
        s_sd = [(SIDE_W - 1, SIDE_H - 1), (SIDE_W, SIDE_H), (SIDE_W + 1, SIDE_H)]
        v = _variants(base, s_sd, rot=cv2.ROTATE_90_CLOCKWISE, crops=((4, 58),))
        self.left = [Bank(v[s], s[0], s[1]) for s in s_sd]
        v = _variants(base, s_sd, rot=cv2.ROTATE_90_COUNTERCLOCKWISE, crops=((4, 58),))
        self.right = [Bank(v[s], s[0], s[1]) for s in s_sd]
        # тайл риичи у боковых игроков: левый — прямой, правый — перевёрнутый на 180°
        s_ri = [(32, 30), (34, 30), (36, 30)]
        v = _variants(base, s_ri, rot=None, crops=((4, 58),))
        self.left_ri = [Bank(v[s], s[0], s[1]) for s in s_ri]
        v = _variants(base, s_ri, rot=cv2.ROTATE_180, crops=((4, 58),))
        self.right_ri = [Bank(v[s], s[0], s[1]) for s in s_ri]
        s_d = [(DORA_W - 3, DORA_H - 5), (DORA_W - 2, DORA_H - 4), (DORA_W - 1, DORA_H - 3)]
        v = _variants(base, s_d, crops=((2, 62), (6, 58)))
        self.dora = [Bank(v[s], s[0], s[1]) for s in s_d]
        import wall as _w
        self.WT = _w.build()
        self.cache = {}

    @staticmethod
    def _hand_items(base):
        items = []
        for k, t in base.items():
            items.append((k, cv2.resize(t, (31, 47), interpolation=cv2.INTER_AREA)))
        return items

    # ------------------------------------------------------------ кэш по содержимому окна
    def _cached(self, tag, win, fn):
        key = (tag, win.shape, win[::3, ::3].tobytes())
        if key in self.cache:
            return self.cache[key]
        if len(self.cache) > 4000:
            self.cache.clear()
        r = fn()
        self.cache[key] = r
        return r

    def _classify(self, im, g, x, y, w, h, banks, tag, pad=5, padv=None):
        padv = pad if padv is None else padv
        x0, y0 = int(round(x)) - pad, int(round(y)) - padv
        if x0 < 0 or y0 < 0 or x0 + w + 2 * pad > FW or y0 + h + 2 * padv > FH:
            return None
        win = im[y0:y0 + h + 2 * padv, x0:x0 + w + 2 * pad]
        face = im[int(round(y)) + 3:int(round(y)) + h - 3, int(round(x)) + 3:int(round(x)) + w - 3]
        if face.size == 0 or not tile_present(face):
            return None

        def run():
            fg = _gray(face)
            if blank(fg):
                return ('5z', 1.0, 1.0)
            top = best_of(banks, g[y0:y0 + h + 2 * padv, x0:x0 + w + 2 * pad], pad, padv)
            return (top[0][0], top[0][1], top[0][1] - top[1][1])
        return self._cached(tag, win, run)

    # ------------------------------------------------------------ зоны
    def mine(self, im, g):
        out = []
        for r, (x0, p, y) in enumerate(OWN_ROWS):
            for c in range(6):
                t = self._classify(im, g, x0 + p * c, y, OWN_W, OWN_H, self.own, 'own', pad=5)
                if t is None:
                    return out
                out.append(t)
        return out

    def across(self, im, g):
        out = []
        for r, (x0, p, y, h) in enumerate(ACR_ROWS):
            for c in range(6):
                t = self._classify(im, g, x0 - p * c, y, ACR_W, h, self.acr, 'acr%d' % r, pad=5)
                if t is None:
                    return out
                out.append(t)
        return out

    def side(self, im, g, seat):
        pos = left_xy if seat == 'L' else right_xy
        N, RI = (self.left, self.left_ri) if seat == 'L' else (self.right, self.right_ri)
        out, ri = [], None
        order = [(c, r) for c in range(3) for r in (range(6) if seat == 'L' else range(5, -1, -1))]
        shift = {}
        for c, r in order:
            x, y = pos(c, r)
            sy = shift.get(c, 0.0)
            y = y + (sy if seat == 'L' else -sy)
            t = self._classify(im, g, x, y, SIDE_W, SIDE_H, N, 'sd' + seat, pad=6, padv=11)
            if t is None:
                # возможно, это тайл риичи (он выше обычного)
                t = None
                break
            tr = self._classify_ri(im, g, x, y, RI, seat)
            if tr is not None and tr[1] > t[1] + 0.1 and tr[1] > 0.55:
                ri = len(out)
                out.append(tr)
                shift[c] = shift.get(c, 0.0) + 10.0
            else:
                out.append(t)
        return out, ri

    def _classify_ri(self, im, g, x, y, banks, seat):
        w, h = banks[0].w, banks[0].h
        x0, y0 = int(round(x)) + 3 - 6, int(round(y)) - 6 - 6
        if x0 < 0 or y0 < 0 or x0 + w + 12 > FW or y0 + h + 12 > FH:
            return None
        top = best_of(banks, g[y0:y0 + h + 12, x0:x0 + w + 12], 6, 6)
        return (top[0][0], top[0][1], top[0][1] - top[1][1])

    def dora_read(self, im, g):
        out = []
        for i in range(5):
            x = DORA_X0 + DORA_PITCH * i
            f = im[DORA_Y + 5:DORA_Y + DORA_H - 5, int(x) + 3:int(x) + DORA_W - 3].astype(int)
            b, gg, r = f[..., 0], f[..., 1], f[..., 2]
            back = ((b - r > 60) & (b > 150)).mean()
            light = (((r + gg + b) / 3) > 170).mean()
            if not (back < 0.5 and light > 0.3):
                out.append(None)
                continue
            fg = _gray(f)
            if (fg < 150).mean() < 0.1:
                out.append(('5z', 1, 1))
                continue
            x0, y0 = int(x) - 4, DORA_Y - 4
            top = best_of(self.dora, g[y0:y0 + DORA_H + 8, x0:x0 + DORA_W + 8], 4, 4)
            out.append((top[0][0], round(top[0][1], 2), round(top[0][1] - top[1][1], 2)))
        return out

    # ------------------------------------------------------------ стена, ход, счётчики
    @staticmethod
    def teal(im):
        x0, x1, y0, y1 = WALL_BOX
        reg = im[y0:y1, x0:x1].astype(int)
        b, g, r = reg[..., 0], reg[..., 1], reg[..., 2]
        return (g > 105) & (b > 105) & (g - r > 35)

    def wall(self, im):
        m = self.teal(im)
        if m.sum() < 40:
            return None
        cols = m.any(0)
        runs, s = [], None
        for i, v in enumerate(cols):
            if v and s is None:
                s = i
            if not v and s is not None:
                runs.append((s, i - 1)); s = None
        if s is not None:
            runs.append((s, len(cols) - 1))
        runs = [r for r in runs if r[1] - r[0] >= 1]
        if len(runs) < 3:
            return None
        s_ = ''
        for a, b in runs[-2:]:
            sub = m[:, a:b + 1].astype(np.uint8) * 255
            ys = np.where(sub.any(1))[0]
            sub = sub[ys[0]:ys[-1] + 1]
            d = cv2.resize(sub, (8, 12), interpolation=cv2.INTER_AREA).astype(float) / 255
            s_ += min(self.WT, key=lambda c: ((self.WT[c] - d) ** 2).sum())
        return int(s_)

    @staticmethod
    def turn(im):
        im = im.astype(int)
        out = {}
        for k, (x0, x1, y0, y1) in TURN_BOX.items():
            reg = im[y0:y1, x0:x1]
            b, g, r = reg[..., 0], reg[..., 1], reg[..., 2]
            out[k] = int(((r > 170) & (g > 165) & (b < 130) & (abs(r - g) < 35)).sum())
        k = max(out, key=out.get)
        return (k if out[k] >= 25 else None), out

    # ------------------------------------------------------------ рука
    def hand(self, im):
        """Рука по фиксированным слотам. Возвращает список (код, уверенность) или None для нечитаемого тайла.
        Количество тайлов считается по наличию белой грани, а не по успеху распознавания:
        блик или анимация не должны «съедать» тайлы."""
        g = _gray(im[600:720, 290:1240])
        half = cv2.resize(g, (g.shape[1] // 2, g.shape[0] // 2), interpolation=cv2.INTER_AREA)
        res = []
        for i in range(13):
            x = HAND_X0 + HAND_PITCH * i
            if not self._slot_present(im, x):
                break
            res.append(self._hand_slot(half, im, x))
        n = len(res)
        if n == 13:
            for gap in (21, 0):
                x = HAND_X0 + HAND_PITCH * 12 + HAND_PITCH + gap
                if self._slot_present(im, x):
                    res.append(self._hand_slot(half, im, x, pad=10))
                    break
        return res

    @staticmethod
    def _slot_present(im, x):
        tx = int(x)
        if tx + 58 > FW:
            return False
        return tile_present(im[HAND_Y + 6:HAND_Y + 84, tx + 4:tx + 58])

    def _hand_slot(self, half, im, x, pad=6):
        px = int((x - 290) / 2) - pad
        py = int((HAND_Y - 600) / 2) - 4
        win = half[max(0, py):py + 47 + 8, max(0, px):px + 31 + 2 * pad]
        if win.shape[0] < 47 or win.shape[1] < 31:
            return None
        key = ('hand', win.shape, win[::2, ::2].astype(np.uint8).tobytes(), round(red_fraction(im[HAND_Y + 26:HAND_Y + 72, int(x) + 4:int(x) + 58]), 2))
        if key in self.cache:
            return self.cache[key]
        s, _ = self.hand_bank.match(win, 0, 0)
        j = int(np.argmax(s))
        sc = float(s[j])
        r = None
        if sc >= 0.35:
            code = self.hand_bank.keys[j]
            tx = int(x)
            face = im[HAND_Y + 26:HAND_Y + 72, tx + 4:tx + 58]
            rf = red_fraction(face)
            if code in ('3p', '5p', '7p') and rf > 0.10:
                code = '5pr'
            elif code in ('4s', '5s', '6s') and rf > 0.10:
                code = '5sr'
            elif code in ('4m', '5m', '6m') and rf > 0.13:
                code = '5mr'
            r = (code, sc)
        self.cache[key] = r
        return r

    @staticmethod
    def seat_round(im):
        """Твой ветер места (по тому, в каком углу красная метка дилера) и ветер раунда (Восток/Юг по ширине надписи)."""
        a = im.astype(int)
        b, g, r = a[..., 0], a[..., 1], a[..., 2]
        red = (r > 140) & (g < 90) & (b < 90)
        sc = {k: int(red[y0:y1, x0:x1].sum()) for k, (x0, x1, y0, y1) in SEAT_BOX.items()}
        k = max(sc, key=sc.get)
        seat = SEAT_FROM_DEALER[k] if sc[k] >= 60 else None
        t = ((g > 105) & (b > 105) & (g - r > 35))[260:282, 755:850]
        cols = np.where(t.any(0))[0]
        rnd = None
        if len(cols) > 10:
            width = cols[-1] - cols[0] + 1      # «East 1» около 49 пикселей, «South 1» заметно шире
            rnd = 'S' if width >= 56 else 'E'
        return seat, rnd

    # ------------------------------------------------------------ всё вместе
    def observe(self, im):
        g = _gray(im)
        wl = self.wall(im)
        if wl is None:
            return dict(ok=False, why='wall')
        L, rl = self.side(im, g, 'L')
        R, rr = self.side(im, g, 'R')
        return dict(ok=True, turn=self.turn(im)[0], dora=[t[0] for t in self.dora_read(im, g) if t], wall=wl,
                    counters={}, disc=dict(me=[t[0] for t in self.mine(im, g)], right=[t[0] for t in R],
                                           across=[t[0] for t in self.across(im, g)], left=[t[0] for t in L]),
                    riichi_idx=dict(left=rl, right=rr), melds=[], seat_round=self.seat_round(im), hand=[(t[0] if t else '?') for t in self.hand(im)])
